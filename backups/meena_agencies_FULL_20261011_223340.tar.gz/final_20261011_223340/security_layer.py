"""
security_layer.py — Safety & security additions for Meena Agencies.
Pure addition. Existing functionality unchanged.
Zero external dependencies (stdlib only).
"""
import hashlib, json, os, shutil, stat
from datetime import datetime, timedelta
from pathlib import Path

PARENT = Path(__file__).parent.parent
AUDIT_LOG       = PARENT / "audit.jsonl"
SESSIONS_FILE   = PARENT / "sessions.json"
RATE_LIMIT_FILE = PARENT / "rate_limit.json"
BACKUP_DIR      = PARENT / "backups"
SALT_FILE       = PARENT / ".meena_salt"

SESSION_HOURS   = 8
MAX_ATTEMPTS    = 999999  # effectively disabled — local single-owner app
LOCKOUT_MINUTES = 15
BACKUP_KEEP     = 30


def harden_file_permissions():
    """chmod 600 on all sensitive files."""
    names = ["retailers.json","orders.json","users.json","approval_rules.json",
             "audit.jsonl","sessions.json","rate_limit.json","inventory.csv",
             ".meena_salt","meena.db"]
    done = 0
    for name in names:
        p = PARENT / name
        if p.exists():
            try:
                os.chmod(p, stat.S_IRUSR | stat.S_IWUSR)
                done += 1
            except Exception: pass
    return done


def _get_salt() -> bytes:
    if SALT_FILE.exists():
        try: return SALT_FILE.read_bytes()
        except Exception: pass
    salt = os.urandom(32)
    try:
        SALT_FILE.write_bytes(salt)
        os.chmod(SALT_FILE, stat.S_IRUSR | stat.S_IWUSR)
    except Exception: pass
    return salt


def _derive_key(purpose: str) -> bytes:
    return hashlib.sha256(_get_salt() + purpose.encode()).digest()


def encrypt_field(value: str, purpose: str = "field") -> str:
    if not value: return ""
    key = _derive_key(purpose)
    data = value.encode("utf-8")
    stream = (key * (len(data) // 32 + 1))[:len(data)]
    return bytes(a ^ b for a, b in zip(data, stream)).hex()


def decrypt_field(ciphertext: str, purpose: str = "field") -> str:
    if not ciphertext: return ""
    try: data = bytes.fromhex(ciphertext)
    except ValueError: return ciphertext
    key = _derive_key(purpose)
    stream = (key * (len(data) // 32 + 1))[:len(data)]
    out = bytes(a ^ b for a, b in zip(data, stream))
    try: return out.decode("utf-8")
    except UnicodeDecodeError: return ciphertext


def log_audit(user_id: str, action: str, target: str = "", details: dict = None):
    entry = {"ts": datetime.now().isoformat(timespec="seconds"),
             "user": user_id or "anonymous", "action": action,
             "target": target, "details": details or {}}
    try:
        with open(AUDIT_LOG, "a") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception: pass


def read_audit(limit: int = 200) -> list:
    if not AUDIT_LOG.exists(): return []
    try:
        lines = AUDIT_LOG.read_text().strip().split("\n")
        return [json.loads(l) for l in lines[-limit:] if l.strip()]
    except Exception: return []


def check_rate_limit(identifier: str) -> tuple:
    data = _read_dict(RATE_LIMIT_FILE)
    now = datetime.now()
    e = data.get(identifier, {"count": 0, "since": now.isoformat()})
    try:
        since = datetime.fromisoformat(e["since"])
        if (now - since) > timedelta(minutes=LOCKOUT_MINUTES):
            e = {"count": 0, "since": now.isoformat()}
    except Exception:
        e = {"count": 0, "since": now.isoformat()}
    if e["count"] >= MAX_ATTEMPTS:
        left = LOCKOUT_MINUTES - int((now - datetime.fromisoformat(e["since"])).total_seconds()//60)
        return False, f"🔒 Too many attempts. Try again in {max(1,left)} min."
    return True, ""


def record_attempt(identifier: str, success: bool):
    data = _read_dict(RATE_LIMIT_FILE)
    if success: data.pop(identifier, None)
    else:
        e = data.get(identifier, {"count": 0, "since": datetime.now().isoformat()})
        e["count"] += 1
        data[identifier] = e
    _write_json_secure(RATE_LIMIT_FILE, data)


def create_session(user_id: str, role: str) -> str:
    token = os.urandom(16).hex()
    sessions = _read_dict(SESSIONS_FILE)
    sessions[token] = {"user_id": user_id, "role": role,
                       "expires_at": (datetime.now() + timedelta(hours=SESSION_HOURS)).isoformat(),
                       "created_at": datetime.now().isoformat(timespec="seconds")}
    _write_json_secure(SESSIONS_FILE, sessions)
    log_audit(user_id, "login", details={"role": role})
    return token


def validate_session(token: str):
    if not token: return None
    sessions = _read_dict(SESSIONS_FILE)
    e = sessions.get(token)
    if not e: return None
    try:
        if datetime.fromisoformat(e["expires_at"]) < datetime.now():
            del sessions[token]; _write_json_secure(SESSIONS_FILE, sessions); return None
    except Exception: return None
    return e


def revoke_session(token: str):
    sessions = _read_dict(SESSIONS_FILE)
    e = sessions.pop(token, None)
    if e: log_audit(e["user_id"], "logout")
    _write_json_secure(SESSIONS_FILE, sessions)


def revoke_all_sessions():
    sessions = _read_dict(SESSIONS_FILE)
    for s in sessions.values():
        log_audit(s.get("user_id","?"), "logout-all")
    _write_json_secure(SESSIONS_FILE, {})
    return len(sessions)


def active_sessions() -> list:
    sessions = _read_dict(SESSIONS_FILE)
    now = datetime.now()
    out = []
    for tok, s in sessions.items():
        try:
            if datetime.fromisoformat(s["expires_at"]) > now:
                out.append({**s, "token_short": tok[:8]})
        except Exception: pass
    return out


def hash_password(pin: str, user_id: str = "") -> str:
    return hashlib.sha256((user_id + ":" + _get_salt().hex() + ":" + pin).encode()).hexdigest()


def verify_password(entered: str, stored: str, user_id: str = "") -> bool:
    if not stored: return False
    if hash_password(entered, user_id) == stored: return True
    legacy = [hashlib.sha256(entered.encode()).hexdigest(),
              hashlib.sha256(entered.lower().encode()).hexdigest(),
              hashlib.md5(entered.encode()).hexdigest()]
    return stored in legacy


def daily_backup() -> str:
    try:
        today = datetime.now().strftime("%Y%m%d")
        target = BACKUP_DIR / today
        if target.exists(): return f"already backed up ({today})"
        target.mkdir(parents=True, exist_ok=True)
        os.chmod(target, stat.S_IRWXU)
        n = 0
        for name in ("retailers.json","orders.json","users.json",
                     "approval_rules.json","inventory.csv","meena.db"):
            src = PARENT / name
            if src.exists():
                dst = target / name
                shutil.copy2(src, dst)
                os.chmod(dst, stat.S_IRUSR | stat.S_IWUSR)
                n += 1
        cutoff = datetime.now() - timedelta(days=BACKUP_KEEP)
        for old in BACKUP_DIR.iterdir():
            if old.is_dir() and old.name.isdigit():
                try:
                    if datetime.strptime(old.name, "%Y%m%d") < cutoff:
                        shutil.rmtree(old)
                except Exception: pass
        log_audit("system", "backup", details={"files": n, "target": str(target)})
        return f"✅ {n} files → backups/{today}/"
    except Exception as e:
        return f"backup error: {e}"


def _read_json(p: Path):
    """Read JSON; return whatever is in the file (dict, list, str, None)."""
    if p.exists():
        try:
            data = json.loads(p.read_text())
            return data
        except Exception:
            pass
    return None


def _read_dict(p: Path) -> dict:
    """Read JSON and guarantee a dict return. Coerces list → {str(i): item}."""
    data = _read_json(p)
    if isinstance(data, dict):
        return data
    if isinstance(data, list):
        return {str(i): item for i, item in enumerate(data) if isinstance(item, dict)}
    return {}


def _write_json_secure(p: Path, data):
    try:
        p.write_text(json.dumps(data, indent=2))
        os.chmod(p, stat.S_IRUSR | stat.S_IWUSR)
    except Exception: pass
