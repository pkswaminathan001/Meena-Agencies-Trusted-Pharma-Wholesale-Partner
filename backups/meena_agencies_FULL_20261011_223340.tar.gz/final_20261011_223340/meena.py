"""
meena.py — Unified Meena Agencies App
One URL, two roles:
  - Owner   → full access (approve, edit credit, inventory, view all)
  - Retailer → read-only own data + place orders
"""
import base64, hashlib, json, sys
from datetime import datetime, timedelta
from pathlib import Path
import pandas as pd
import streamlit as st
try:
    import folium
    from streamlit_folium import st_folium
    HAS_MAP = True
except Exception:
    HAS_MAP = False

PARENT = Path(__file__).parent.parent

# ─── BLOCK 1 HELPERS: Payments + Telegram + AI Approvals ───
try:
    import block1_helpers as b1
    B1_LOADED = True
except Exception as _e:
    B1_LOADED = False

try:
    import block2a_morning as morning
    MORNING_LOADED = True
except Exception as _e:
    MORNING_LOADED = False
    _MORNING_ERR = str(_e)

try:
    import block2b_permissions as perms
    PERMS_LOADED = True
except Exception as _e:
    PERMS_LOADED = False
    _PERMS_ERR = str(_e)
    _B1_ERR = str(_e)

try:
    import block15_otp as otp_mod
    OTP_LOADED = True
except Exception as _e:
    OTP_LOADED = False
    _OTP_ERR = str(_e)
    B1_LOADED = True
except Exception as _e:
    B1_LOADED = False
    _B1_ERR = str(_e)


# ─── SECURITY LAYER ───
import sys as _sys
_sys.path.insert(0, str(Path(__file__).parent))
try:
    import security_layer as sec
    SEC_LOADED = True
except Exception as _e:
    SEC_LOADED = False
    _SEC_ERR = str(_e)

sys.path.insert(0, str(PARENT))


# ── URL sanitizer: runs BEFORE set_page_config so "undefined" never persists ──
try:
    _qp = st.query_params
    for _k in list(_qp.keys()):
        if _k == "undefined":
            try: del _qp[_k]
            except Exception: pass
    for _k in list(_qp.keys()):
        try:
            _v = _qp.get(_k)
        except Exception:
            continue
        if isinstance(_v, str) and _v.strip().lower() == "undefined":
            try: del _qp[_k]
            except Exception: pass
    if "page" not in _qp or not _qp.get("page"):
        _qp["page"] = "home"
except Exception:
    pass

st.set_page_config(page_title="Meena Agencies", page_icon="🦚",
                   layout="wide", initial_sidebar_state="collapsed")

# ─── SECURITY STARTUP ───
if SEC_LOADED and "SEC_STARTUP_DONE" not in st.session_state:
    try:
        _n = sec.harden_file_permissions()
        _bk = sec.daily_backup()
        st.session_state["SEC_STARTUP_DONE"] = True
        st.session_state["SEC_LAST_BACKUP"] = _bk
        st.session_state["SEC_FILES_HARDENED"] = _n
    except Exception:
        pass


# ─── Load app's own auth (rbac) for owner ───
try:
    import rbac
    HAS_RBAC = True
except Exception:
    HAS_RBAC = False


# ═══════════════════════════════════════════════════════════
#  CSS
# ═══════════════════════════════════════════════════════════
st.markdown("""
<style>
:root{--bg:#0a0e1a;--bg2:#111827;--card:#1a1f2e;--border:#2a3142;
      --text:#e8eaf6;--muted:#8892b0;--cyan:#00d4ff;--purple:#7b61ff;
      --green:#00d47a;--orange:#ffb547;--red:#ff4d6d;}
html,body,.stApp,[data-testid="stAppViewContainer"]{
    background:var(--bg)!important;color:var(--text)!important;
    font-family:'Inter','Source Sans',sans-serif!important;}
[data-testid="stHeader"]{background:transparent!important;}
#MainMenu,footer{visibility:hidden!important;}
.main .block-container{padding:1.2rem 1.5rem 3rem!important;max-width:1500px!important;}
@media(max-width:768px){.main .block-container{padding:.8rem .8rem 3rem!important;}}

section[data-testid="stSidebar"]{background:#0d1220!important;border-right:1px solid var(--border)!important;}
section[data-testid="stSidebar"] *{color:var(--text)!important;}
section[data-testid="stSidebar"] .stButton>button{
    background:transparent!important;border:1px solid transparent!important;
    color:var(--muted)!important;text-align:left!important;
    justify-content:flex-start!important;font-weight:500!important;
    padding:.5rem .8rem!important;margin:2px 0!important;}
section[data-testid="stSidebar"] .stButton>button:hover{
    background:rgba(0,212,255,.08)!important;color:var(--text)!important;
    border-color:rgba(0,212,255,.25)!important;}
section[data-testid="stSidebar"] [data-testid="stBaseButton-primary"]{
    background:linear-gradient(90deg,rgba(0,212,255,.15),rgba(123,97,255,.15))!important;
    color:var(--cyan)!important;border:1px solid rgba(0,212,255,.4)!important;font-weight:700!important;}

.stButton>button{background:var(--card)!important;color:var(--text)!important;
    border:1px solid var(--border)!important;border-radius:10px!important;
    font-weight:600!important;transition:all .15s ease!important;}
.stButton>button:hover{border-color:var(--cyan)!important;color:var(--cyan)!important;
    box-shadow:0 0 12px rgba(0,212,255,.2)!important;transform:translateY(-1px);}
[data-testid="stBaseButton-primary"]{
    background:linear-gradient(90deg,var(--cyan),var(--purple))!important;
    color:#0a0e1a!important;border:none!important;font-weight:800!important;}

.stTextInput input,.stNumberInput input,.stSelectbox select,
[data-baseweb="select"]>div,[data-baseweb="input"]>div{
    background:var(--card)!important;color:var(--text)!important;
    border-color:var(--border)!important;border-radius:10px!important;}
label{color:var(--muted)!important;}
h1,h2,h3,h4{color:var(--text)!important;font-weight:700!important;}
h1{font-size:1.9rem!important;}h2{font-size:1.4rem!important;}h3{font-size:1.1rem!important;}
@media(max-width:480px){h1{font-size:1.4rem!important;}h2{font-size:1.15rem!important;}}

.hero{background:linear-gradient(135deg,#0d3b66 0%,#4a3a8c 60%,#7b61ff 100%);
    border-radius:18px;padding:1.8rem 2rem 1.6rem;margin-bottom:1.4rem;
    position:relative;overflow:hidden;
    box-shadow:0 8px 40px rgba(123,97,255,.25),inset 0 1px 0 rgba(255,255,255,.08);}
.hero::before{content:"";position:absolute;inset:0;
    background:radial-gradient(circle at 80% 20%,rgba(0,212,255,.25),transparent 55%);
    pointer-events:none;}
.hero-eyebrow{display:inline-block;font-size:.72rem;font-weight:700;letter-spacing:1.5px;
    text-transform:uppercase;background:rgba(255,255,255,.12);
    border:1px solid rgba(255,255,255,.18);border-radius:20px;
    padding:4px 12px;margin-bottom:.8rem;color:#fff;}
.hero h1{margin:0!important;font-size:1.9rem!important;font-weight:800!important;
    color:#fff!important;letter-spacing:-.5px;}
.hero h1 .accent{background:linear-gradient(90deg,#00d4ff,#a78bfa);
    -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;}
.hero p{margin:.5rem 0 1rem!important;color:rgba(255,255,255,.85)!important;
    font-size:.95rem;max-width:640px;}
.hero-stats{display:flex;gap:1.8rem;flex-wrap:wrap;
    border-top:1px solid rgba(255,255,255,.15);padding-top:1rem;margin-top:.4rem;}
.hero-stat-label{font-size:.7rem;color:rgba(255,255,255,.65);
    text-transform:uppercase;letter-spacing:.8px;margin-bottom:2px;}
.hero-stat-value{font-size:1.05rem;color:#fff;font-weight:700;}
@media(max-width:480px){.hero{padding:1.2rem 1.1rem;border-radius:14px;}
    .hero h1{font-size:1.3rem!important;}.hero p{font-size:.82rem;}
    .hero-stats{gap:1rem;}.hero-stat-value{font-size:.9rem;}}

.metric-tile{background:var(--card);border:1px solid var(--border);
    border-top:3px solid var(--cyan);border-radius:14px;
    padding:.9rem 1rem;position:relative;overflow:hidden;height:100%;}
.metric-tile.purple{border-top-color:var(--purple);}
.metric-tile.green{border-top-color:var(--green);}
.metric-tile.orange{border-top-color:var(--orange);}
.metric-tile.red{border-top-color:var(--red);}
.metric-tile .label{font-size:.7rem;letter-spacing:1.2px;text-transform:uppercase;
    color:var(--muted);margin-bottom:.4rem;}
.metric-tile .value{font-size:1.6rem;font-weight:800;line-height:1;color:var(--cyan);}
.metric-tile.purple .value{color:var(--purple);}
.metric-tile.green .value{color:var(--green);}
.metric-tile.orange .value{color:var(--orange);}
.metric-tile.red .value{color:var(--red);}

.section-head{display:flex;align-items:center;gap:.5rem;
    margin:1.5rem 0 .9rem;font-size:1.1rem;font-weight:700;color:var(--text);}
.section-head::before{content:"";display:inline-block;width:4px;height:20px;
    border-radius:2px;background:linear-gradient(180deg,var(--cyan),var(--purple));}

.med-card{background:linear-gradient(180deg,var(--card),var(--bg2));
    border:1px solid var(--border);border-radius:14px;
    padding:.9rem .8rem .6rem;margin-bottom:.6rem;transition:all .15s ease;text-align:center;}
.med-card:hover{border-color:var(--cyan);box-shadow:0 6px 20px rgba(0,212,255,.1);}
.med-emoji{font-size:2rem;line-height:1;filter:drop-shadow(0 0 8px rgba(0,212,255,.3));}
.med-name{font-weight:700;font-size:.88rem;color:var(--text);margin-top:.4rem;
    min-height:2.4rem;line-height:1.2;}
.med-price{font-size:1.1rem;font-weight:800;margin-top:.4rem;}
.med-meta{font-size:.7rem;color:var(--muted);margin-top:.1rem;}

.bill-card{background:var(--card);border:1px solid var(--border);
    border-left:3px solid var(--cyan);border-radius:12px;
    padding:.9rem 1.1rem;margin-bottom:.7rem;}
.bill-card.pending{border-left-color:var(--orange);}
.bill-card.cancelled{border-left-color:var(--red);}
.bill-card.delivered{border-left-color:var(--green);}
.bill-card.approved{border-left-color:var(--cyan);}
.bill-card .row1{display:flex;justify-content:space-between;align-items:center;gap:.6rem;flex-wrap:wrap;}
.bill-card .oid{font-weight:700;color:var(--text);font-size:.9rem;}
.bill-card .badge{font-size:.62rem;font-weight:700;padding:3px 9px;border-radius:20px;
    text-transform:uppercase;letter-spacing:.5px;}
.badge.pending{background:rgba(255,181,71,.15);color:#ffb547;}
.badge.cancelled{background:rgba(255,77,109,.15);color:#ff4d6d;}
.badge.delivered{background:rgba(0,212,122,.15);color:#00d47a;}
.badge.approved{background:rgba(0,212,255,.15);color:#00d4ff;}
.bill-card .row2{font-size:.75rem;color:var(--muted);margin-top:.3rem;
    display:flex;gap:1.2rem;flex-wrap:wrap;}
.bill-card .row3{display:flex;justify-content:space-between;align-items:center;
    margin-top:.6rem;padding-top:.6rem;border-top:1px dashed #2a3142;}
.bill-card .total{color:var(--cyan);font-weight:800;font-size:1.05rem;}

.sidebar-brand{padding:.8rem 0 .6rem;text-align:center;}
.sidebar-brand .name{font-weight:800;color:var(--cyan);font-size:.9rem;letter-spacing:.5px;}
.sidebar-brand .sub{font-size:.68rem;color:var(--muted);letter-spacing:1px;margin-top:2px;}

.badge-role{display:inline-block;padding:3px 10px;border-radius:20px;
    font-size:.7rem;font-weight:700;letter-spacing:1px;}

@media(max-width:768px){
    section[data-testid="stSidebar"]{position:fixed!important;top:0!important;left:0!important;
        height:100vh!important;width:82vw!important;max-width:320px!important;
        z-index:999999!important;transform:translateX(-100%)!important;
        transition:transform .25s ease!important;overflow-y:auto!important;}
    section[data-testid="stSidebar"][aria-expanded="true"]{transform:translateX(0)!important;}
}
html,body,[data-testid="stAppViewContainer"]{overflow-x:hidden!important;max-width:100vw!important;}
</style>
""", unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════════════════
def logo_html(h=44):
    for p in (Path(__file__).parent/"static"/"logo.png", PARENT/"logo.png"):
        if p.exists():
            try:
                b64 = base64.b64encode(p.read_bytes()).decode()
                return f'<img src="data:image/png;base64,{b64}" style="height:{h}px;" alt="Meena">'
            except Exception: pass
    return "🦚"

def money(v):
    try: return f"₹{float(v):,.2f}"
    except Exception: return "₹0.00"

def find_col(df, *c):
    if df is None or df.empty: return None
    for cand in c:
        if cand in df.columns: return cand
    lower = {str(x).lower():x for x in df.columns}
    for cand in c:
        if cand.lower() in lower: return lower[cand.lower()]
    return None

@st.cache_data(ttl=10)
def load_inventory():
    for p in (PARENT/"inventory.csv", Path("inventory.csv")):
        if p.exists():
            try:
                df = pd.read_csv(p); df.columns=[c.strip().lower() for c in df.columns]
                return df
            except Exception: pass
    return pd.DataFrame()

def load_retailers():
    for p in (PARENT/"retailers.json", Path("retailers.json")):
        if p.exists():
            try:
                d = json.loads(p.read_text())
                return d if isinstance(d, list) else list(d.values())
            except Exception: pass
    return []

def save_retailers(data):
    try:
        if SEC_LOADED: sec.log_audit("owner", "save_retailers", details={"count": len(data) if hasattr(data,"__len__") else 0})
    except Exception: pass
    for p in (PARENT/"retailers.json", Path("retailers.json")):
        if p.exists():
            p.write_text(json.dumps(data, indent=2))
            return True
    return False

@st.cache_data(ttl=10)
def load_orders():
    for p in (PARENT/"orders.json", Path("orders.json")):
        if p.exists():
            try:
                d = json.loads(p.read_text())
                return d if isinstance(d, list) else list(d.values())
            except Exception: pass
    return []

def save_orders(data):
    try:
        if SEC_LOADED: sec.log_audit(st.session_state.get("retailer_id","owner"), "save_orders", details={"count": len(data) if hasattr(data,"__len__") else 0})
    except Exception: pass
    for p in (PARENT/"orders.json", Path("orders.json")):
        if p.exists():
            p.write_text(json.dumps(data, indent=2))
            return True
    return False




# ══════════════════════════════════════════════════════════
#  APPROVAL RULES — persisted to approval_rules.json
# ══════════════════════════════════════════════════════════
DEFAULT_RULES = {
    "auto_approve_max_value": 5000.0,       # ₹ under this → auto approve
    "trusted_min_orders": 3,                # customers with ≥ this many orders → auto
    "restricted_categories": ["Injection", "Insulin"],  # always manual
    "block_overdue_days": 60,               # block if overdue > this
    "auto_approve_enabled": True,
    "manual_approvers": ["OWNER"],          # user IDs allowed to approve
}

def load_rules():
    for p in (PARENT/"approval_rules.json", Path("approval_rules.json")):
        if p.exists():
            try:
                data = json.loads(p.read_text())
                return {**DEFAULT_RULES, **data}
            except Exception: pass
    return dict(DEFAULT_RULES)

def save_rules(rules):
    try:
        if SEC_LOADED: sec.log_audit("owner", "save_rules", details=dict(rules))
    except Exception: pass
    for p in (PARENT/"approval_rules.json", Path("approval_rules.json")):
        try:
            p.write_text(json.dumps(rules, indent=2))
            return True
        except Exception: pass
    return False


def decide_approval(order, retailer, rules):
    """Return (decision, reason, decided_by).
       decision: 'auto' | 'manual'
    """
    if not rules.get("auto_approve_enabled", True):
        return "manual", "Auto-approve disabled", None

    total = float(order.get("total", 0))
    items = order.get("items", []) or []

    # ── Rule 1: Restricted categories → manual ──
    restricted = [c.lower() for c in rules.get("restricted_categories", [])]
    for it in items:
        nm = (it.get("medicine") or it.get("name") or "").lower()
        if any(r in nm for r in restricted):
            return "manual", f"Restricted category ({[r for r in restricted if r in nm][0].title()})", None

    # ── Rule 2: Block overdue ──
    if retailer:
        try:
            overdue = float(retailer.get("overdue_days") or 0)
            if overdue > float(rules.get("block_overdue_days", 60)):
                return "manual", f"Overdue {int(overdue)} days", None
        except Exception: pass

    # ── Rule 3: High value → manual ──
    max_val = float(rules.get("auto_approve_max_value", 0))
    if total > max_val:
        return "manual", f"High value order ({money(total)} > {money(max_val)})", None

    # ── Rule 4: Trusted customer → auto ──
    if retailer:
        order_count = int(retailer.get("_order_count") or 0)
        if order_count >= int(rules.get("trusted_min_orders", 3)):
            return "auto", f"Trusted customer ({order_count} prior orders)", "System"

    # ── Rule 5: Low value → auto ──
    if total <= max_val:
        return "auto", f"Low value order ({money(total)})", "System"

    return "manual", "Manual review", None


# ═══════════════════════════════════════════════════════════
#  LANDING — role picker
# ═══════════════════════════════════════════════════════════
def landing():
    _, mid, _ = st.columns([1,2,1])
    with mid:
        st.markdown(f'<div style="text-align:center;margin:2rem 0 1rem;">{logo_html(96)}</div>',
                    unsafe_allow_html=True)
        st.markdown('<h1 style="text-align:center;color:#00d4ff;margin-bottom:.2rem;">MEENA AGENCIES</h1>',
                    unsafe_allow_html=True)
        st.markdown('<p style="text-align:center;color:#8892b0;margin-top:0;letter-spacing:2px;">WHOLESALE PHARMA PARTNER</p>',
                    unsafe_allow_html=True)
        st.markdown("---")
        c1, c2 = st.columns(2)
        with c1:
            if st.button("👑  Owner Login", use_container_width=True, type="primary"):
                st.session_state.role_pick = "owner"; st.rerun()
        with c2:
            if st.button("🏪  Retailer Login", use_container_width=True):
                st.session_state.role_pick = "retailer"; st.rerun()


# ═══════════════════════════════════════════════════════════
#  OWNER LOGIN
# ═══════════════════════════════════════════════════════════
def owner_login():
    _, mid, _ = st.columns([1,2,1])
    with mid:
        st.markdown(f'<div style="text-align:center;margin:1rem 0;">{logo_html(72)}</div>',
                    unsafe_allow_html=True)
        st.markdown('<h2 style="text-align:center;color:#f59e0b;">👑 Owner Login</h2>',
                    unsafe_allow_html=True)
        st.markdown("---")
        pw = st.text_input("Owner Password", type="password", key="opw")
        if SEC_LOADED:
            _ok, _msg = sec.check_rate_limit("OWNER")
            if not _ok:
                st.error(_msg); st.stop()
        c1, c2 = st.columns(2)
        if c2.button("← Back", use_container_width=True):
            st.session_state.clear(); st.rerun()
        if c1.button("Sign In", use_container_width=True, type="primary"):
            if not pw:
                st.error("Enter password."); return
            ok = False
            if HAS_RBAC:
                for args in [
                    ("owner", "owner", pw),
                    ("owner", "OWNER", pw),
                    ("OWNER", "owner", pw),
                    ("OWNER", "OWNER", pw),
                    ("Owner", "owner", pw),
                ]:
                    try:
                        v, u, e = rbac.verify_login(*args)
                        if v:
                            ok = True
                            break
                    except Exception:
                        continue
            if not ok:
                # fallback: users.json hash
                for p in (PARENT/"users.json", Path("users.json")):
                    if p.exists():
                        try:
                            users = json.loads(p.read_text())
                            for u in users:
                                if u.get("id","").upper()=="OWNER":
                                    stored = u.get("pin_hash","")
                                    cands = {pw, hashlib.sha256(pw.encode()).hexdigest(),
                                            hashlib.sha256(pw.lower().encode()).hexdigest()}
                                    if stored in cands: ok=True
                        except Exception: pass
            try:
                if SEC_LOADED: sec.record_attempt("OWNER", bool(ok))
            except Exception: pass
            if not ok:
                st.error("❌ Wrong password."); return
            try:
                if SEC_LOADED:
                    _tok = sec.create_session("OWNER", "owner")
                    st.session_state["session_token"] = _tok
            except Exception: pass
            st.session_state.role = "owner"
            st.session_state.user_name = "Swaminathan"
            st.session_state.page = "home"
            st.rerun()


# ═══════════════════════════════════════════════════════════
#  RETAILER LOGIN
# ═══════════════════════════════════════════════════════════
def retailer_login():
    _, mid, _ = st.columns([1,2,1])
    with mid:
        st.markdown(f'<div style="text-align:center;margin:1rem 0;">{logo_html(72)}</div>',
                    unsafe_allow_html=True)
        st.markdown('<h2 style="text-align:center;color:#00d4ff;">🏪 Retailer Login</h2>',
                    unsafe_allow_html=True)
        st.markdown("---")
        rid = st.text_input("Retailer ID", placeholder="RET001")
        pin = st.text_input("PIN", type="password", placeholder="4-digit PIN")
        if SEC_LOADED and rid:
            _ok, _msg = sec.check_rate_limit(str(rid).upper())
            if not _ok:
                st.error(_msg); st.stop()
        c1, c2 = st.columns(2)
        if c2.button("← Back", use_container_width=True):
            st.session_state.clear(); st.rerun()
        if c1.button("Sign In", use_container_width=True, type="primary"):
            if not rid or not pin:
                st.error("Enter both."); return
            retailers = load_retailers()
            target = None
            for r in retailers:
                if str(r.get("id","")).upper() == rid.strip().upper():
                    target = r; break
            if not target:
                st.error(f"Retailer {rid.upper()} not found."); return
            stored = target.get("pin_hash","")
            cands = {pin.strip(),
                     hashlib.sha256(pin.strip().encode()).hexdigest(),
                     hashlib.sha256(pin.strip().lower().encode()).hexdigest(),
                     hashlib.md5(pin.strip().encode()).hexdigest()}
            _hit = (stored in cands)
            try:
                if SEC_LOADED: sec.record_attempt(str(rid).upper(), _hit)
            except Exception: pass
            if not _hit:
                st.error("❌ Invalid PIN."); return
            try:
                if SEC_LOADED:
                    _tok = sec.create_session(str(rid).upper(), "retailer")
                    st.session_state["session_token"] = _tok
            except Exception: pass
            st.session_state.role = "retailer"
            st.session_state.retailer = target
            st.session_state.retailer_id = rid.strip().upper()
            st.session_state.user_name = target.get("owner") or target.get("shop") or rid
            st.session_state.page = "home"
            st.rerun()


# ═══════════════════════════════════════════════════════════
#  OWNER PAGES
# ═══════════════════════════════════════════════════════════
def owner_home():
    orders = load_orders()
    rets = load_retailers()
    inv = load_inventory()

    pending = [o for o in orders if (o.get("status") or "").lower()=="pending"]
    approved = [o for o in orders if (o.get("status") or "").lower()=="approved"]
    pval = sum(float(o.get("total",0)) for o in pending)

    now = datetime.now(); h = now.hour
    greet = "Good morning" if h<12 else ("Good afternoon" if h<17 else "Good evening")

    st.markdown(f"""
    <div class="hero">
        <div class="hero-eyebrow">👑 OWNER DASHBOARD</div>
        <h1>{greet}, <span class="accent">{st.session_state.user_name}</span></h1>
        <p>Control center — approvals, retailers, inventory, ledger.</p>
        <div class="hero-stats">
            <div><div class="hero-stat-label">Pending</div><div class="hero-stat-value">{len(pending)}</div></div>
            <div><div class="hero-stat-label">Orders</div><div class="hero-stat-value">{len(orders)}</div></div>
            <div><div class="hero-stat-label">Retailers</div><div class="hero-stat-value">{len(rets)}</div></div>
            <div><div class="hero-stat-label">Pending Value</div><div class="hero-stat-value">{money(pval)}</div></div>
        </div>
    </div>""", unsafe_allow_html=True)

    m1,m2,m3,m4 = st.columns(4)
    for col,tone,label,val,sub in [
        (m1,"orange","Pending Orders",str(len(pending)),"awaiting"),
        (m2,"cyan","Total Orders",str(len(orders)),"all time"),
        (m3,"green","Approved",str(len(approved)),"this period"),
        (m4,"purple","Inventory Value",money(0),"see inventory"),
    ]:
        with col:
            st.markdown(f"""
            <div class="metric-tile {tone}">
                <div class="label">{label}</div>
                <div class="value">{val}</div>
                <div style="font-size:.68rem;color:#8892b0;margin-top:.3rem;">{sub}</div>
            </div>""", unsafe_allow_html=True)


def owner_approvals():
    st.markdown("## ✅ Pending Approvals")
    orders = load_orders()
    pending = [o for o in orders if (o.get("status") or "").lower()=="pending"]
    if not pending:
        st.info("No pending approvals."); return

    st.caption(f"**{len(pending)}** order(s) awaiting")
    for i, o in enumerate(pending):
        oid = o.get("order_id","—")
        with st.container():
            st.markdown(f"""
            <div class="bill-card pending">
                <div class="row1"><div class="oid">⚠️ {oid}</div><div class="badge pending">PENDING</div></div>
                <div class="row2">
                    <span>🏪 {o.get('shop','—')} · {o.get('retailer_id','—')}</span>
                    <span>📅 {o.get('placed_at','—')}</span>
                    <span>📦 {len(o.get('items',[]))} item(s)</span>
                </div>
                <div class="row3"><span style="color:#8892b0;font-size:.75rem;">Total</span>
                <span class="total">{money(o.get('total',0))}</span></div>
            </div>""", unsafe_allow_html=True)
            c1, c2 = st.columns(2)
            if c1.button("✅ Approve", key=f"ap_{oid}_{i}", use_container_width=True, type="primary"):
                for x in orders:
                    if x.get("order_id")==oid: x["status"]="Approved"
                save_orders(orders); st.cache_data.clear()
                st.success(f"{oid} approved"); st.rerun()
            if c2.button("❌ Reject", key=f"rj_{oid}_{i}", use_container_width=True):
                for x in orders:
                    if x.get("order_id")==oid: x["status"]="Cancelled"
                save_orders(orders); st.cache_data.clear()
                st.warning(f"{oid} rejected"); st.rerun()


def owner_retailers():
    st.markdown("## 🏪 Retailers")
    st.caption("Manage retailers — edit credit limits, view balances")
    rets = load_retailers()
    if not rets:
        st.warning("No retailers."); return

    for i, r in enumerate(rets):
        rid = r.get("id","—")
        shop = r.get("shop","—")
        owner = r.get("owner","—")
        limit = float(r.get("credit_limit") or 0)
        out = float(r.get("outstanding") or 0)
        avail = limit - out
        pct = (out/limit*100) if limit else 0

        with st.expander(f"🏪 {shop}  ·  {rid}  ·  {money(out)} outstanding", expanded=False):
            c1,c2,c3 = st.columns(3)
            with c1:
                st.markdown(f'<div class="metric-tile"><div class="label">Credit Limit</div><div class="value">{money(limit)}</div></div>', unsafe_allow_html=True)
            with c2:
                st.markdown(f'<div class="metric-tile orange"><div class="label">Outstanding</div><div class="value">{money(out)}</div><div style="font-size:.68rem;color:#8892b0;margin-top:.3rem;">{pct:.0f}% used</div></div>', unsafe_allow_html=True)
            with c3:
                st.markdown(f'<div class="metric-tile green"><div class="label">Available</div><div class="value">{money(avail)}</div></div>', unsafe_allow_html=True)

            st.markdown(f"**Owner:** {owner}  ·  **Phone:** {r.get('phone','—')}")
            st.markdown(f"**Address:** {r.get('address','—')}")
            st.markdown(f"**Status:** {r.get('status','—')}")

            # ── Owner can EDIT ──
            st.markdown("##### ✏️ Edit Credit Terms")
            e1, e2, e3 = st.columns(3)
            with e1:
                new_limit = st.number_input("Credit Limit (₹)", min_value=0.0,
                                            value=float(limit), step=10000.0,
                                            key=f"lim_{rid}_{i}")
            with e2:
                new_out = st.number_input("Outstanding (₹)", min_value=0.0,
                                          value=float(out), step=1000.0,
                                          key=f"out_{rid}_{i}")
            with e3:
                new_status = st.selectbox("Status", ["Active","Suspended","Closed"],
                                          index=["Active","Suspended","Closed"].index(r.get("status","Active"))
                                          if r.get("status","Active") in ["Active","Suspended","Closed"] else 0,
                                          key=f"stat_{rid}_{i}")
            if st.button("💾 Save Changes", key=f"save_{rid}_{i}", type="primary"):
                rets[i]["credit_limit"] = new_limit
                rets[i]["outstanding"] = new_out
                rets[i]["status"] = new_status
                save_retailers(rets); st.cache_data.clear()
                st.success(f"Updated {shop}"); st.rerun()


def owner_orders():
    st.markdown("## 📦 All Orders")
    orders = load_orders()
    if not orders:
        st.info("No orders yet."); return

    statuses = sorted({(o.get("status") or "pending").lower() for o in orders})
    c1, c2 = st.columns([1,3])
    with c1:
        sel = st.selectbox("Filter", ["All"] + statuses)
    with c2:
        q = st.text_input("Search", placeholder="Order ID, retailer, shop…",
                          label_visibility="collapsed").strip().lower()

    filtered = orders
    if sel != "All":
        filtered = [o for o in filtered if (o.get("status") or "").lower() == sel]
    if q:
        filtered = [o for o in filtered if q in str(o.get("order_id","")).lower()
                    or q in str(o.get("retailer_id","")).lower()
                    or q in str(o.get("shop","")).lower()]

    st.caption(f"**{len(filtered)}** order(s)")
    for o in filtered[:40]:
        st.markdown(f"""
        <div class="bill-card {(o.get('status') or 'pending').lower()}">
            <div class="row1"><div class="oid">🧾 {o.get('order_id','—')}</div>
            <div class="badge {(o.get('status') or 'pending').lower()}">{(o.get('status') or 'PENDING').upper()}</div></div>
            <div class="row2"><span>🏪 {o.get('shop','—')} · {o.get('retailer_id','—')}</span>
            <span>📅 {o.get('placed_at','—')}</span></div>
            <div class="row3"><span style="color:#8892b0;font-size:.75rem;">Total</span>
            <span class="total">{money(o.get('total',0))}</span></div>
        </div>""", unsafe_allow_html=True)


def owner_inventory():
    st.markdown("## 📦 Inventory")
    df = load_inventory()
    if df.empty:
        st.error("inventory.csv not found."); return

    name_col = find_col(df,"medicine_name","medicine","name","product","item")
    qty_col = find_col(df,"quantity","stock","qty","available")
    price_col = find_col(df,"cost_price","price","rate","mrp")

    units = int(pd.to_numeric(df[qty_col],errors="coerce").fillna(0).sum()) if qty_col else 0
    value = (pd.to_numeric(df[qty_col],errors="coerce").fillna(0)
             * pd.to_numeric(df[price_col],errors="coerce").fillna(0)).sum() if qty_col and price_col else 0

    m1,m2,m3 = st.columns(3)
    with m1:
        st.markdown(f'<div class="metric-tile"><div class="label">Unique Medicines</div><div class="value">{df[name_col].nunique() if name_col else len(df)}</div></div>', unsafe_allow_html=True)
    with m2:
        st.markdown(f'<div class="metric-tile green"><div class="label">Total Units</div><div class="value">{units:,}</div></div>', unsafe_allow_html=True)
    with m3:
        st.markdown(f'<div class="metric-tile orange"><div class="label">Inventory Value</div><div class="value">{money(value)}</div></div>', unsafe_allow_html=True)

    st.dataframe(df, use_container_width=True, height=420)

    if qty_col and name_col:
        low = df[pd.to_numeric(df[qty_col],errors="coerce").fillna(0) < 100]
        if not low.empty:
            st.markdown('<div class="section-head">⚠️ Low Stock</div>', unsafe_allow_html=True)
            st.dataframe(low[[name_col, qty_col]], use_container_width=True)


def owner_ledger():
    st.markdown("## 💰 Ledger")
    rets = load_retailers()
    if not rets: st.warning("No data."); return

    total_lim = sum(float(r.get("credit_limit") or 0) for r in rets)
    total_out = sum(float(r.get("outstanding") or 0) for r in rets)

    m1,m2,m3 = st.columns(3)
    with m1:
        st.markdown(f'<div class="metric-tile"><div class="label">Credit Extended</div><div class="value">{money(total_lim)}</div></div>', unsafe_allow_html=True)
    with m2:
        st.markdown(f'<div class="metric-tile orange"><div class="label">Total Outstanding</div><div class="value">{money(total_out)}</div></div>', unsafe_allow_html=True)
    with m3:
        pct = (total_out/total_lim*100) if total_lim else 0
        st.markdown(f'<div class="metric-tile green"><div class="label">Utilization</div><div class="value">{pct:.1f}%</div></div>', unsafe_allow_html=True)

    df = pd.DataFrame([{"Retailer":r.get("shop","—"), "ID":r.get("id","—"),
                        "Limit":r.get("credit_limit",0), "Outstanding":r.get("outstanding",0),
                        "Available":float(r.get("credit_limit") or 0)-float(r.get("outstanding") or 0),
                        "Status":r.get("status","—")} for r in rets])
    df = df.sort_values("Outstanding", ascending=False)
    st.dataframe(df, use_container_width=True)


def owner_jarvis():
    st.markdown("## 🤖 JARVIS — Vanakkam!")
    st.session_state.setdefault("jmsgs",[("bot","Vanakkam! Ask about orders, retailers, stock, revenue.")])
    for who,msg in st.session_state.jmsgs:
        color = "#00d4ff" if who=="user" else "#7b61ff"
        bg = "linear-gradient(135deg,#00d4ff,#7b61ff)" if who=="user" else "#1a1f2e"
        fg = "#0a0e1a" if who=="user" else "#e8eaf6"
        align = "margin-left:auto;border-radius:14px 14px 4px 14px;" if who=="user" else "margin-right:auto;border-radius:14px 14px 14px 4px;"
        st.markdown(f'<div style="background:{bg};color:{fg};padding:.6rem 1rem;{align}max-width:80%;margin:.4rem 0;">{msg}</div>',
                    unsafe_allow_html=True)

    c1,c2,c3,c4 = st.columns(4)
    for col, txt in [(c1,"Pending orders?"),(c2,"Top 3 by outstanding"),
                     (c3,"Low stock items"),(c4,"Total revenue")]:
        if col.button(txt, key=f"jq_{txt}", use_container_width=True):
            _j_handle(txt)
    q = st.text_input("Ask JARVIS…", key="jin", placeholder="Type a question…")
    if q: _j_handle(q)

def _j_handle(q):
    # Try Groq first if key exists
    try:
        _ctx = _build_business_context()
        _reply = _groq_ask(q, _ctx)
        if _reply and not _reply.startswith("Groq error"):
            st.session_state.jmsgs.append(("user", q))
            st.session_state.jmsgs.append(("bot", _reply + "\n\n_\u2014 Powered by Llama 3.3 via Groq_"))
            st.rerun()
            return
    except Exception:
        pass
    # Fallback: rules
    orders = load_orders(); rets = load_retailers(); inv = load_inventory()
    ql = q.lower()
    if "pending" in ql:
        n = len([o for o in orders if (o.get("status") or "").lower()=="pending"])
        a = f"You have **{n}** pending order(s)."
    elif "top" in ql or "outstanding" in ql:
        top = sorted(rets, key=lambda r: float(r.get("outstanding") or 0), reverse=True)[:3]
        a = "Top 3 by outstanding:\n\n" + "\n".join(f"{i+1}. {r.get('shop','?')} — {money(r.get('outstanding',0))}" for i,r in enumerate(top))
    elif "low" in ql and "stock" in ql:
        qty = find_col(inv,"quantity","stock","qty")
        nm  = find_col(inv,"medicine_name","medicine","name")
        if qty and nm:
            inv2 = inv.copy(); inv2["_q"]=pd.to_numeric(inv2[qty],errors="coerce").fillna(0)
            low = inv2[inv2["_q"]<100].head(5)
            a = "Low stock:\n\n" + "\n".join(f"• {r[nm]} — {int(r['_q'])} units" for _,r in low.iterrows()) if not low.empty else "No low stock."
        else: a = "Inventory unreadable."
    elif "revenue" in ql or "total" in ql:
        tot = sum(float(o.get("total",0)) for o in orders)
        a = f"Total revenue: **{money(tot)}** across {len(orders)} orders."
    else:
        a = "Try: *pending orders*, *top retailers*, *low stock*, or *revenue*."
    st.session_state.jmsgs.append(("user", q))
    st.session_state.jmsgs.append(("bot", a))
    st.rerun()




# ═══════════════════════════════════════════════════════════
#  TAMIL NADU MAP — districts, cities, coordinates
# ═══════════════════════════════════════════════════════════
TN_LOCATIONS = {
    "chennai": (13.0827, 80.2707), "coimbatore": (11.0168, 76.9558),
    "madurai": (9.9252, 78.1198), "trichy": (10.7905, 78.7047),
    "tiruchirappalli": (10.7905, 78.7047), "salem": (11.6643, 78.1460),
    "tirunelveli": (8.7139, 77.7567), "erode": (11.3410, 77.7172),
    "vellore": (12.9165, 79.1325), "thanjavur": (10.7870, 79.1378),
    "tiruppur": (11.1085, 77.3411), "dindigul": (10.3624, 77.9695),
    "kanchipuram": (12.8342, 79.7036), "tiruvannamalai": (12.2253, 79.0747),
    "kanyakumari": (8.0883, 77.5385), "nagercoil": (8.1833, 77.4119),
    "cuddalore": (11.7480, 79.7714), "karur": (10.9601, 78.0766),
    "namakkal": (11.2189, 78.1677), "krishnagiri": (12.5186, 78.2137),
    "dharmapuri": (12.1211, 78.1580), "pudukkottai": (10.3833, 78.8001),
    "ramanathapuram": (9.3639, 78.8395), "sivaganga": (9.8433, 78.4809),
    "virudhunagar": (9.5680, 77.9624), "theni": (10.0104, 77.4768),
    "ooty": (11.4102, 76.6950), "nilgiris": (11.4102, 76.6950),
    "ariyalur": (11.1401, 79.0756), "perambalur": (11.2342, 78.8807),
    "villupuram": (11.9401, 79.4861), "tiruvarur": (10.7725, 79.6368),
    "nagapattinam": (10.7660, 79.8425), "mayiladuthurai": (11.1018, 79.6529),
    "ranipet": (12.9249, 79.3305), "tirupathur": (12.4954, 78.5678),
    "chengalpattu": (12.6819, 79.9888), "kallakurichi": (11.7384, 78.9597),
    "tenkasi": (8.9594, 77.3149), "tuticorin": (8.7642, 78.1348),
    "thoothukudi": (8.7642, 78.1348), "hosur": (12.7409, 77.8253),
    "ambur": (12.7826, 78.7162), "tambaram": (12.9229, 80.1275),
    "chromepet": (12.9516, 80.1462), "avadi": (13.1147, 80.1098),
    "porur": (13.0359, 80.1567), "velachery": (12.9791, 80.2202),
    "omr": (12.9010, 80.2279), "guindy": (13.0067, 80.2206),
    "tnagar": (13.0418, 80.2341), "anna nagar": (13.0850, 80.2101),
}

TN_CENTER = (11.1271, 78.6569)


def _extract_city(address: str) -> str:
    """Pull a known city from an address string."""
    if not address: return ""
    low = address.lower()
    # Longest names first to catch 'tiruchirappalli' before 'trichy'
    for name in sorted(TN_LOCATIONS.keys(), key=len, reverse=True):
        if name in low:
            return name
    return ""


def _geocode(address: str) -> tuple:
    """Return (lat, lon, city) — falls back to TN center."""
    city = _extract_city(address)
    if city:
        lat, lon = TN_LOCATIONS[city]
        return lat, lon, city
    return TN_CENTER[0], TN_CENTER[1], ""


def _risk_color(outstanding: float, limit: float, days: int = 0) -> str:
    """Return marker color based on outstanding ratio + age."""
    if limit <= 0:
        return "#8892b0"    # grey — no credit line
    ratio = outstanding / limit
    if ratio >= 0.9 or days > 90:
        return "#ff4d6d"    # red — bad debt risk
    if ratio >= 0.6 or days > 45:
        return "#ffb547"    # orange — watch closely
    if outstanding > 0:
        return "#00d4ff"    # cyan — normal outstanding
    return "#00d47a"        # green — clear


def page_owner_map():
    """Collection command center — aging, field plan, map, insights."""
    import streamlit.components.v1 as components

    rets = load_retailers()
    orders = load_orders()
    if not rets:
        st.warning("No retailers."); return

    # ══════════════════════════════════════════════════════════
    #  ENRICH: aging, collection score, WhatsApp link
    # ══════════════════════════════════════════════════════════
    rows = []
    for r in rets:
        addr = r.get("address","") or r.get("shop","") or ""
        lat, lon, city = _geocode(addr)
        limit = float(r.get("credit_limit") or 0)
        out = float(r.get("outstanding") or 0)
        ratio = (out/limit) if limit else 0

        rid = r.get("id","")
        my_orders = [o for o in orders
                     if str(o.get("retailer_id","")).upper()==str(rid).upper()]
        last_dt = None
        for o in my_orders:
            try:
                d = pd.to_datetime(o.get("placed_at"), errors="coerce", format="mixed")
                if pd.notna(d) and (last_dt is None or d > last_dt):
                    last_dt = d
            except Exception: pass
        days_since = (datetime.now() - last_dt).days if last_dt else 999

        # Aging bucket (using days_since as proxy for how long money's been stuck)
        if out <= 0:
            aging = "Clear"
        elif days_since <= 30:
            aging = "0-30"
        elif days_since <= 60:
            aging = "31-60"
        elif days_since <= 90:
            aging = "61-90"
        else:
            aging = "90+"

        # Collection score: unpaid money × how long it's been stuck
        score = out * (days_since / 30 if days_since < 999 else 20)

        # WhatsApp link
        phone = str(r.get("phone") or "").strip().replace(" ", "").replace("-", "")
        if phone and not phone.startswith("91") and len(phone) == 10:
            phone = "91" + phone
        wa = f"https://wa.me/{phone}?text=Hi%20{r.get('owner','')},%20this%20is%20a%20friendly%20reminder%20about%20your%20outstanding%20balance%20of%20%E2%82%B9{out:,.0f}." if phone else ""

        rows.append({
            "id": rid, "shop": r.get("shop","—"), "owner": r.get("owner","—"),
            "phone": r.get("phone","—"), "phone_clean": phone,
            "address": addr, "city": city, "lat": lat, "lon": lon,
            "limit": limit, "outstanding": out, "available": limit - out,
            "ratio": ratio, "days_since": days_since, "aging": aging,
            "score": score, "wa": wa,
            "orders_count": len(my_orders),
            "status": r.get("status","—"),
        })

    df = pd.DataFrame(rows)

    # ══════════════════════════════════════════════════════════
    #  HERO: Command strip
    # ══════════════════════════════════════════════════════════
    total_out = df["outstanding"].sum()
    overdue_60 = df[df["aging"].isin(["61-90","90+"])]["outstanding"].sum()
    high_risk = df[df["score"] > 0].sort_values("score", ascending=False)

    st.markdown(f"""
    <div class="hero" style="background:linear-gradient(135deg,#7f1d1d 0%,#991b1b 40%,#dc2626 100%);">
        <div class="hero-eyebrow">🚨 COLLECTION COMMAND CENTER</div>
        <h1>You're owed <span class="accent">{money(total_out)}</span> today</h1>
        <p>{len(df[df["outstanding"]>0])} retailer(s) with dues · {money(overdue_60)} stuck over 60 days</p>
        <div class="hero-stats">
            <div><div class="hero-stat-label">Total Outstanding</div>
                 <div class="hero-stat-value">{money(total_out)}</div></div>
            <div><div class="hero-stat-label">Overdue 60+ days</div>
                 <div class="hero-stat-value">{money(overdue_60)}</div></div>
            <div><div class="hero-stat-label">Active Retailers</div>
                 <div class="hero-stat-value">{len(df)}</div></div>
            <div><div class="hero-stat-label">Avg per Retailer</div>
                 <div class="hero-stat-value">{money(total_out/len(df) if len(df) else 0)}</div></div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # ══════════════════════════════════════════════════════════
    #  AGING BUCKETS
    # ══════════════════════════════════════════════════════════
    st.markdown('<div class="section-head">⏰ Aging Analysis</div>', unsafe_allow_html=True)

    buckets = [
        ("0-30",   "Fresh",       "#00d47a", "safe"),
        ("31-60",  "Watch",       "#00d4ff", "info"),
        ("61-90",  "Overdue",     "#ffb547", "warn"),
        ("90+",    "Bad Debt",    "#ff4d6d", "risk"),
    ]
    cols = st.columns(4)
    for col, (key, label, color, tone) in zip(cols, buckets):
        sub = df[df["aging"] == key]
        amt = sub["outstanding"].sum()
        with col:
            st.markdown(f"""
            <div class="metric-tile" style="border-top-color:{color};">
                <div class="label">{label} ({key}d)</div>
                <div class="value" style="color:{color};">{len(sub)}</div>
                <div style="font-size:.72rem;color:#8892b0;margin-top:.3rem;">{money(amt)}</div>
            </div>
            """, unsafe_allow_html=True)

    # ══════════════════════════════════════════════════════════
    #  TODAY'S FIELD PLAN — the killer feature
    # ══════════════════════════════════════════════════════════
    st.markdown('<div class="section-head">📋 Today\'s Field Plan</div>', unsafe_allow_html=True)
    st.caption("Ranked by **collection score** (outstanding × days stuck). Start from #1.")

    plan = df[df["outstanding"] > 0].sort_values("score", ascending=False).reset_index(drop=True)

    if plan.empty:
        st.success("🎉 No outstanding balances. All clear!")
    else:
        for i, row in plan.iterrows():
            rank = i + 1
            aging_color = {"0-30":"#00d47a","31-60":"#00d4ff",
                           "61-90":"#ffb547","90+":"#ff4d6d","Clear":"#8892b0"}[row["aging"]]

            st.markdown(f"""
            <div class="bill-card" style="border-left-color:{aging_color};">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:.6rem;">
                    <div style="display:flex;align-items:center;gap:.7rem;flex:1;min-width:200px;">
                        <div style="width:36px;height:36px;border-radius:50%;
                                    background:{aging_color};color:#0a0e1a;font-weight:900;
                                    display:flex;align-items:center;justify-content:center;
                                    font-size:1rem;flex-shrink:0;">{rank}</div>
                        <div>
                            <div style="font-weight:700;color:#e8eaf6;font-size:.92rem;">{row['shop']}</div>
                            <div style="font-size:.72rem;color:#8892b0;margin-top:2px;">
                                {row['owner']} · {row['city'].title() or '—'} · {row['orders_count']} orders
                            </div>
                        </div>
                    </div>
                    <div style="text-align:right;">
                        <div style="color:{aging_color};font-weight:800;font-size:1.05rem;">
                            {money(row['outstanding'])}
                        </div>
                        <div style="font-size:.7rem;color:#8892b0;margin-top:2px;">
                            {row['aging']} days · {int(row['ratio']*100)}% of credit
                        </div>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)

            # Action row
            a1, a2, a3, a4 = st.columns([1,1,1,2])
            with a1:
                if row["phone_clean"]:
                    st.markdown(
                        f'<a href="tel:{row["phone_clean"]}" target="_blank" '
                        f'style="display:block;text-align:center;padding:.5rem;'
                        f'background:#1a1f2e;border:1px solid #2a3142;border-radius:8px;'
                        f'color:#e8eaf6;text-decoration:none;font-size:.8rem;font-weight:600;">'
                        f'📞 Call</a>', unsafe_allow_html=True)
                else:
                    st.markdown('<div style="text-align:center;padding:.5rem;color:#8892b0;font-size:.8rem;">📞 No phone</div>', unsafe_allow_html=True)
            with a2:
                if row["wa"]:
                    st.markdown(
                        f'<a href="{row["wa"]}" target="_blank" '
                        f'style="display:block;text-align:center;padding:.5rem;'
                        f'background:#1a1f2e;border:1px solid #00d47a44;border-radius:8px;'
                        f'color:#00d47a;text-decoration:none;font-size:.8rem;font-weight:600;">'
                        f'💬 WhatsApp</a>', unsafe_allow_html=True)
            with a3:
                if row["phone_clean"]:
                    sms = f"sms:{row['phone_clean']}?body=Reminder:%20Outstanding%20balance%20%E2%82%B9{row['outstanding']:,.0f}%20is%20due.%20Please%20arrange%20payment."
                    st.markdown(
                        f'<a href="{sms}" target="_blank" '
                        f'style="display:block;text-align:center;padding:.5rem;'
                        f'background:#1a1f2e;border:1px solid #2a3142;border-radius:8px;'
                        f'color:#e8eaf6;text-decoration:none;font-size:.8rem;font-weight:600;">'
                        f'✉️ SMS</a>', unsafe_allow_html=True)
            with a4:
                st.markdown(
                    f'<div style="padding:.5rem .8rem;background:#1a1f2e;border:1px solid #2a3142;'
                    f'border-radius:8px;font-size:.72rem;color:#c5cae9;">'
                    f'📍 <b>{row["address"] or "No address"}</b></div>',
                    unsafe_allow_html=True)

    # ══════════════════════════════════════════════════════════
    #  MAP with numbered markers matching the field plan
    # ══════════════════════════════════════════════════════════
    st.markdown('<div class="section-head">🗺️ Route Map</div>', unsafe_allow_html=True)
    st.caption("Numbers match the Field Plan above — tap to see details")

    if not plan.empty:
        centre_lat = float(plan["lat"].mean())
        centre_lon = float(plan["lon"].mean())
        zoom = 7 if len(plan) > 5 else 10

        markers_js = ""
        for i, r in plan.iterrows():
            rank = i + 1
            aging_color = {"0-30":"#00d47a","31-60":"#00d4ff",
                           "61-90":"#ffb547","90+":"#ff4d6d","Clear":"#8892b0"}[r["aging"]]
            markers_js += f"""
            L.marker([{r['lat']}, {r['lon']}], {{
                icon: L.divIcon({{
                    html: '<div style="width:36px;height:36px;border-radius:50%;background:{aging_color};color:#0a0e1a;font-weight:900;display:flex;align-items:center;justify-content:center;border:3px solid #fff;box-shadow:0 0 12px {aging_color};">{rank}</div>',
                    iconSize: [36,36], iconAnchor: [18,18], className: ''
                }})
            }}).addTo(map).bindPopup(
                `<div style="font-family:sans-serif;min-width:220px;">
                    <div style="font-size:15px;font-weight:800;color:{aging_color};">#{rank} · {r['shop']}</div>
                    <div style="color:#888;font-size:11px;margin-bottom:8px;">{r['id']} &middot; {r['city'].title()}</div>
                    <b>Owner:</b> {r['owner']}<br>
                    <b>Phone:</b> {r['phone']}<br>
                    <b>Address:</b> {r['address']}<br>
                    <hr style="border-color:#ddd;">
                    <div style="font-size:14px;color:#d97706;font-weight:700;">Outstanding: ₹{r['outstanding']:,.0f}</div>
                    <div style="font-size:11px;color:#666;">{r['aging']} days &middot; {int(r['ratio']*100)}% of credit</div>
                    <div style="margin-top:8px;font-size:11px;"><b>Collection score:</b> {int(r['score']):,}</div>
                </div>`
            );
            """

        html = f"""
        <!DOCTYPE html>
        <html><head><meta charset="utf-8"/>
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
        <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
        <style>
            html, body {{ margin:0; padding:0; background:#0a0e1a; }}
            #map {{ width:100%; height:520px; }}
            .leaflet-popup-content-wrapper {{ background:#1a1f2e; color:#e8eaf6; border-radius:10px; border:1px solid #2a3142; }}
            .leaflet-popup-tip {{ background:#1a1f2e; }}
            .leaflet-popup-content {{ color:#c5cae9; }}
        </style></head>
        <body><div id="map"></div>
        <script>
            var map = L.map('map').setView([{centre_lat}, {centre_lon}], {zoom});
            L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{{z}}/{{y}}/{{x}}', {{
                attribution: '&copy; Esri &copy; OpenStreetMap', maxZoom: 16
            }}).addTo(map);
            {markers_js}
        </script></body></html>
        """
        components.html(html, height=560, scrolling=False)

    # ══════════════════════════════════════════════════════════
    #  INSIGHTS
    # ══════════════════════════════════════════════════════════
    st.markdown('<div class="section-head">🔥 Business Insights</div>', unsafe_allow_html=True)

    ins1, ins2, ins3 = st.columns(3)

    # Dormant
    dormant = df[(df["days_since"] > 60) & (df["days_since"] < 999)].sort_values("days_since", ascending=False)
    with ins1:
        st.markdown(f"""
        <div class="bill-card" style="border-left-color:#ffb547;">
            <div style="font-weight:700;color:#ffb547;font-size:.85rem;">😴 Dormant Accounts</div>
            <div style="color:#8892b0;font-size:.72rem;margin:.3rem 0 .6rem;">No order in 60+ days</div>
            <div style="color:#e8eaf6;font-size:1.6rem;font-weight:800;">{len(dormant)}</div>
        </div>""", unsafe_allow_html=True)
        for _, r in dormant.head(3).iterrows():
            st.caption(f"• {r['shop']} — {r['days_since']} days")

    # High risk
    with ins2:
        st.markdown(f"""
        <div class="bill-card" style="border-left-color:#ff4d6d;">
            <div style="font-weight:700;color:#ff4d6d;font-size:.85rem;">🚨 High-Risk Accounts</div>
            <div style="color:#8892b0;font-size:.72rem;margin:.3rem 0 .6rem;">>90% credit used</div>
            <div style="color:#e8eaf6;font-size:1.6rem;font-weight:800;">{len(df[df['ratio']>0.9])}</div>
        </div>""", unsafe_allow_html=True)
        for _, r in df[df["ratio"]>0.9].head(3).iterrows():
            st.caption(f"• {r['shop']} — {int(r['ratio']*100)}% used")

    # Fresh orders
    with ins3:
        fresh = df[(df["days_since"] <= 30) & (df["days_since"] < 999)]
        st.markdown(f"""
        <div class="bill-card" style="border-left-color:#00d47a;">
            <div style="font-weight:700;color:#00d47a;font-size:.85rem;">✅ Active Retailers</div>
            <div style="color:#8892b0;font-size:.72rem;margin:.3rem 0 .6rem;">Ordered in last 30 days</div>
            <div style="color:#e8eaf6;font-size:1.6rem;font-weight:800;">{len(fresh)}</div>
        </div>""", unsafe_allow_html=True)
        for _, r in fresh.head(3).iterrows():
            st.caption(f"• {r['shop']} — {r['days_since']} days ago")

    # ══════════════════════════════════════════════════════════
    #  EXPORT
    # ══════════════════════════════════════════════════════════
    st.markdown('<div class="section-head">📥 Export Run Sheet</div>', unsafe_allow_html=True)
    st.caption("Download today\'s collection plan to your phone or print it")

    if not plan.empty:
        run_sheet = plan[["id","shop","owner","phone","city","outstanding","aging","days_since","score"]].copy()
        run_sheet.columns = ["ID","Shop","Owner","Phone","City","Outstanding","Aging","Days Since","Score"]
        csv = run_sheet.to_csv(index=False)
        c1, c2 = st.columns(2)
        with c1:
            st.download_button("📥 Download Field Plan (CSV)", data=csv,
                               file_name=f"field_plan_{datetime.now():%Y%m%d}.csv",
                               mime="text/csv", use_container_width=True, type="primary")
        with c2:
            st.markdown(
                f'<div style="text-align:center;padding:.6rem;background:#1a1f2e;'
                f'border:1px solid #2a3142;border-radius:8px;color:#8892b0;font-size:.8rem;">'
                f'📱 {len(plan)} stops · est. {len(plan)*30} min travel</div>',
                unsafe_allow_html=True)


def owner_settings():
    """Edit approval rules + business defaults."""
    st.markdown("## ⚙️ Settings")
    st.caption("Configure auto-approval rules, thresholds, and restrictions")

    rules = load_rules()

    st.markdown('<div class="section-head">🎯 Auto-Approval Rules</div>', unsafe_allow_html=True)
    c1, c2 = st.columns(2)
    with c1:
        rules["auto_approve_enabled"] = st.toggle(
            "Enable auto-approval",
            value=bool(rules.get("auto_approve_enabled", True)))
    with c2:
        rules["auto_approve_max_value"] = st.number_input(
            "Auto-approve orders under (₹)",
            min_value=0.0, step=500.0,
            value=float(rules.get("auto_approve_max_value", 5000)))

    c3, c4 = st.columns(2)
    with c3:
        rules["trusted_min_orders"] = st.number_input(
            "Trusted customer threshold (orders)",
            min_value=0, step=1,
            value=int(rules.get("trusted_min_orders", 3)))
    with c4:
        rules["block_overdue_days"] = st.number_input(
            "Block if overdue for (days)",
            min_value=0, step=5,
            value=int(rules.get("block_overdue_days", 60)))

    st.markdown('<div class="section-head">🚫 Restricted Categories</div>', unsafe_allow_html=True)
    st.caption("Orders containing these always need manual approval")
    ALL_CATS = ["Antibiotic","Pain Relief","Cardiac","Diabetes","Gastro",
                "Allergy","Injection","Syrup","Inhaler","Powder","Insulin"]
    current = set(rules.get("restricted_categories", []))
    picked = []
    cols = st.columns(4)
    for i, cat in enumerate(ALL_CATS):
        with cols[i % 4]:
            if st.checkbox(cat, value=(cat in current), key=f"restrict_{cat}"):
                picked.append(cat)
    rules["restricted_categories"] = picked

    st.markdown("---")
    c5, c6 = st.columns(2)
    with c5:
        if st.button("💾 Save Rules", type="primary", use_container_width=True):
            if save_rules(rules):
                st.success("✅ Rules saved."); st.rerun()
    with c6:
        if st.button("↩️ Reset to Defaults", use_container_width=True):
            save_rules(dict(DEFAULT_RULES)); st.success("✅ Reset."); st.rerun()

    st.markdown('<div class="section-head">👁️ Current Rules</div>', unsafe_allow_html=True)
    st.markdown(f"""
    <div class="bill-card">
        <div style="font-size:.85rem;line-height:1.9;">
            <b>Auto-approve:</b> {"✅ Enabled" if rules.get("auto_approve_enabled") else "❌ Disabled"}<br>
            <b>Under:</b> {money(rules.get("auto_approve_max_value", 0))}<br>
            <b>Trusted after:</b> {rules.get("trusted_min_orders", 0)} orders<br>
            <b>Block overdue:</b> {rules.get("block_overdue_days", 0)} days<br>
            <b>Restricted:</b> {", ".join(rules.get("restricted_categories", [])) or "none"}
        </div>
    </div>
    """, unsafe_allow_html=True)


def owner_security():
    """Security Center — status, sessions, audit log."""
    st.markdown("## 🛡️ Security Center")
    st.caption("Live security status, active sessions, and full audit trail")

    if not SEC_LOADED:
        st.error("Security layer not loaded: " + globals().get("_SEC_ERR","?"))
        return

    # ── Status cards ──
    files_hardened = st.session_state.get("SEC_FILES_HARDENED", 0)
    last_backup = st.session_state.get("SEC_LAST_BACKUP", "pending")
    sessions = sec.active_sessions()
    attempts = sec._read_json(sec.RATE_LIMIT_FILE)
    # Handle any shape: dict, list, None, str
    if not isinstance(attempts, dict):
        attempts = {}
    locked = 0
    for _k, _v in attempts.items():
        try:
            if isinstance(_v, dict) and int(_v.get("count", 0)) >= 5:
                locked += 1
        except Exception:
            pass

    c1,c2,c3,c4 = st.columns(4)
    with c1:
        st.markdown(f'<div class="metric-tile green"><div class="label">Files Protected</div><div class="value">{files_hardened}</div><div style="font-size:.68rem;color:#8892b0;margin-top:.3rem;">chmod 600</div></div>', unsafe_allow_html=True)
    with c2:
        st.markdown(f'<div class="metric-tile"><div class="label">Active Sessions</div><div class="value">{len(sessions)}</div><div style="font-size:.68rem;color:#8892b0;margin-top:.3rem;">8h expiry</div></div>', unsafe_allow_html=True)
    with c3:
        st.markdown(f'<div class="metric-tile orange"><div class="label">Locked Users</div><div class="value">{locked}</div><div style="font-size:.68rem;color:#8892b0;margin-top:.3rem;">5-fail lockout</div></div>', unsafe_allow_html=True)
    with c4:
        st.markdown(f'<div class="metric-tile purple"><div class="label">Last Backup</div><div class="value" style="font-size:.95rem;">{last_backup[:16]}</div></div>', unsafe_allow_html=True)

    # ── Actions ──
    st.markdown('<div class="section-head">⚙️ Actions</div>', unsafe_allow_html=True)
    a1, a2, a3 = st.columns(3)
    with a1:
        if st.button("🔒 Re-harden files", use_container_width=True):
            n = sec.harden_file_permissions()
            sec.log_audit("OWNER", "harden", details={"files": n})
            st.success(f"✅ {n} files chmod 600")
    with a2:
        if st.button("💾 Backup now", use_container_width=True):
            msg = sec.daily_backup()
            st.success(msg)
    with a3:
        if st.button("🚪 Force logout all", use_container_width=True, type="primary"):
            n = sec.revoke_all_sessions()
            st.success(f"✅ Revoked {n} session(s)")

    # ── Active sessions table ──
    st.markdown('<div class="section-head">👥 Active Sessions</div>', unsafe_allow_html=True)
    if sessions:
        import pandas as _pd
        sdf = _pd.DataFrame([{
            "User": s["user_id"], "Role": s["role"],
            "Token": s["token_short"] + "…",
            "Created": s.get("created_at","")[:19],
            "Expires": s["expires_at"][:19],
        } for s in sessions])
        st.dataframe(sdf, use_container_width=True, hide_index=True)
    else:
        st.info("No active sessions.")

    # ── Audit log ──
    st.markdown('<div class="section-head">📜 Audit Log (last 200)</div>', unsafe_allow_html=True)
    entries = sec.read_audit(200)
    if entries:
        import pandas as _pd
        audit_df = _pd.DataFrame([{
            "Time": e["ts"],
            "User": e["user"],
            "Action": e["action"],
            "Target": e.get("target",""),
            "Details": str(e.get("details",""))[:60],
        } for e in reversed(entries)])
        st.dataframe(audit_df, use_container_width=True, hide_index=True, height=400)
        csv = audit_df.to_csv(index=False)
        st.download_button("📥 Download audit log (CSV)", data=csv,
                           file_name=f"audit_{datetime.now():%Y%m%d}.csv",
                           mime="text/csv", use_container_width=True)
    else:
        st.info("No audit entries yet — they'll appear as you use the app.")


def owner_expiry():
    """Batch & Expiry Manager — never lose money to expired stock."""
    st.markdown("## ⏰ Batch & Expiry Manager")
    st.caption("Track expiring batches, avoid losses, plan discounts")

    inv = load_inventory()
    if inv.empty:
        st.error("inventory.csv not found.")
        return

    nm  = find_col(inv, "medicine_name", "medicine", "name")
    exp = find_col(inv, "expiry_date", "expiry", "exp")
    qty = find_col(inv, "quantity", "stock", "qty")
    prc = find_col(inv, "cost_price", "price", "rate")
    bat = find_col(inv, "batch_number", "batch", "lot")
    if not exp or not nm:
        st.error(f"Missing columns. Found: {list(inv.columns)}")
        return

    df = inv.copy()
    df["_exp"] = pd.to_datetime(df[exp], errors="coerce", format="mixed")
    df["_qty"] = pd.to_numeric(df[qty], errors="coerce").fillna(0).astype(int) if qty else 0
    df["_prc"] = pd.to_numeric(df[prc], errors="coerce").fillna(0) if prc else 0
    df["_val"] = df["_qty"] * df["_prc"]
    today = pd.Timestamp.now().normalize()
    df["_days"] = (df["_exp"] - today).dt.days

    def bucket(d):
        if pd.isna(d): return "No Date"
        if d < 0:      return "Expired"
        if d <= 30:    return "< 30 days"
        if d <= 90:    return "30-90 days"
        if d <= 180:   return "90-180 days"
        return "> 180 days"

    df["_bucket"] = df["_days"].apply(bucket)

    expired = df[df["_bucket"] == "Expired"]
    soon    = df[df["_bucket"] == "< 30 days"]
    warn    = df[df["_bucket"] == "30-90 days"]
    ok_long = df[df["_bucket"] == "> 180 days"]

    st.markdown('<div class="section-head">📊 Expiry Overview</div>', unsafe_allow_html=True)
    c1, c2, c3, c4 = st.columns(4)
    for col, tone, label, count, val in [
        (c1, "red",    "⛔ Expired",       len(expired), money(expired["_val"].sum())),
        (c2, "orange", "🚨 < 30 days", len(soon),    money(soon["_val"].sum())),
        (c3, "purple", "⚠ 30-90 days",    len(warn),    money(warn["_val"].sum())),
        (c4, "green",  "✅ > 180 days",    len(ok_long), money(ok_long["_val"].sum())),
    ]:
        with col:
            st.markdown(f'<div class="metric-tile {tone}"><div class="label">{label}</div><div class="value">{count}</div><div style="font-size:.7rem;color:#8892b0;margin-top:.3rem;">{val}</div></div>', unsafe_allow_html=True)

    st.markdown('<div class="section-head">🚨 Critical — Action Required</div>', unsafe_allow_html=True)
    action = df[df["_bucket"].isin(["Expired", "< 30 days"])].sort_values("_days")
    if action.empty:
        st.success("✅ No expired or near-expiry batches. Great job!")
    else:
        st.error(f"⚠ {len(action)} batch(es) need action — value at risk: **{money(action['_val'].sum())}**")
        show_cols = [c for c in [nm, bat, exp, qty, prc] if c]
        st.dataframe(action[show_cols], use_container_width=True, hide_index=True)

    st.markdown('<div class="section-head">📥 Suggested Discounts</div>', unsafe_allow_html=True)
    disc = warn.copy()
    if disc.empty:
        st.info("No batches in the 30–90 day window.")
    else:
        disc["Suggested Discount"] = disc["_days"].apply(
            lambda d: "40%" if d <= 45 else ("25%" if d <= 60 else "15%")
        )
        show_cols = [c for c in [nm, bat, exp, qty] if c] + ["Suggested Discount"]
        st.dataframe(disc[show_cols], use_container_width=True, hide_index=True)


def render_printable_invoice(order, key=None):
    """Print-ready HTML invoice. Download -> open -> Ctrl+P -> Save PDF."""
    oid    = order.get("order_id", "-")
    rid    = order.get("retailer_id", "-")
    shop   = order.get("shop", "-")
    placed = order.get("placed_at", "-")
    status = (order.get("status") or "pending").upper()
    total  = float(order.get("total", 0))
    items  = order.get("items", []) or []

    rows_html = ""
    for i, it in enumerate(items, 1):
        nmn = it.get("medicine") or it.get("name") or "-"
        qn  = it.get("qty") or it.get("quantity") or 0
        prn = float(it.get("price") or it.get("unit_price") or 0)
        ltn = prn * int(qn)
        rows_html += (
            f'<tr>'
            f'<td style="text-align:center;">{i}</td>'
            f'<td>{nmn}</td>'
            f'<td style="text-align:center;">{int(qn)}</td>'
            f'<td style="text-align:right;">Rs.{prn:,.2f}</td>'
            f'<td style="text-align:right;">Rs.{ltn:,.2f}</td>'
            f'</tr>'
        )
    if not rows_html:
        rows_html = '<tr><td colspan="5" style="text-align:center;color:#888;">No items</td></tr>'

    inv_no = f"INV-{datetime.now():%Y%m%d}-{oid[-4:]}" if oid != "-" else f"INV-{datetime.now():%Y%m%d}"
    today = datetime.now().strftime("%d-%b-%Y")

    css = """
    * { box-sizing:border-box; }
    body { font-family:'Segoe UI',Arial,sans-serif; background:#f5f5f5; margin:0; padding:24px; }
    .invoice { max-width:800px; margin:0 auto; background:#fff; border-radius:12px; overflow:hidden; box-shadow:0 4px 24px rgba(0,0,0,.08); }
    .head { background:linear-gradient(135deg,#0d3b66,#7b61ff); color:#fff; padding:28px 32px; }
    .head h1 { margin:0; font-size:26px; font-weight:800; letter-spacing:-0.5px; }
    .head .sub { opacity:.9; font-size:13px; margin-top:4px; }
    .head .inv-no { float:right; text-align:right; font-size:12px; }
    .head .inv-no b { display:block; font-size:18px; margin-top:4px; }
    .meta { display:flex; justify-content:space-between; padding:22px 32px; border-bottom:1px solid #eee; }
    .meta div { font-size:13px; line-height:1.7; }
    .meta .label { color:#888; font-size:11px; text-transform:uppercase; letter-spacing:.5px; }
    .meta .value { color:#222; font-weight:600; }
    table { width:100%; border-collapse:collapse; }
    thead th { background:#f9f9f9; color:#555; font-size:11px; text-transform:uppercase; letter-spacing:.5px; padding:12px 16px; text-align:left; border-bottom:2px solid #eee; }
    tbody td { padding:12px 16px; font-size:13px; color:#333; border-bottom:1px solid #f0f0f0; }
    .total-row { background:#f9f9f9; font-weight:800; font-size:16px; }
    .total-row td { padding:16px; color:#0d3b66; }
    .footer { text-align:center; padding:24px 32px; color:#888; font-size:11px; border-top:1px solid #eee; }
    @media print { body { background:#fff; padding:0; } .invoice { box-shadow:none; border-radius:0; } }
    """
    html = (
        f'<!DOCTYPE html><html><head><meta charset="utf-8">'
        f'<title>Invoice {inv_no}</title><style>{css}</style></head><body>'
        f'<div class="invoice">'
        f'<div class="head">'
        f'<div class="inv-no">Invoice #<b>{inv_no}</b>Date: {today}</div>'
        f'<h1>MEENA AGENCIES</h1>'
        f'<div class="sub">Trusted Pharma Wholesale Partner</div>'
        f'</div>'
        f'<div class="meta">'
        f'<div><div class="label">Billed To</div><div class="value">{shop}</div>'
        f'<div style="color:#666;font-size:12px;margin-top:4px;">Retailer ID: {rid}</div></div>'
        f'<div style="text-align:right;"><div class="label">Order ID</div><div class="value">{oid}</div>'
        f'<div style="color:#666;font-size:12px;margin-top:4px;">Placed: {placed}</div></div>'
        f'</div>'
        f'<table><thead><tr>'
        f'<th style="width:40px;text-align:center;">#</th>'
        f'<th>Description</th>'
        f'<th style="width:80px;text-align:center;">Qty</th>'
        f'<th style="width:110px;text-align:right;">Unit Price</th>'
        f'<th style="width:120px;text-align:right;">Line Total</th>'
        f'</tr></thead><tbody>{rows_html}'
        f'<tr class="total-row"><td colspan="4" style="text-align:right;">TOTAL</td>'
        f'<td style="text-align:right;">Rs.{total:,.2f}</td></tr>'
        f'</tbody></table>'
        f'<div class="footer">Computer-generated invoice. Thank you for your business!<br>'
        f'Meena Agencies &middot; Wholesale Pharma Distributor &middot; Thanjavur</div>'
        f'</div></body></html>'
    )
    st.download_button(
        "🖨️ Download Invoice",
        data=html, file_name=f"{inv_no}.html", mime="text/html",
        use_container_width=True, key=key or f"inv_{oid}"
    )


SALESPEOPLE_FILE = PARENT / "salespeople.json"

def load_salespeople():
    for p in (SALESPEOPLE_FILE, Path("salespeople.json")):
        if p.exists():
            try:
                d = json.loads(p.read_text())
                return d if isinstance(d, list) else list(d.values())
            except Exception:
                pass
    return []

def save_salespeople(data):
    for p in (SALESPEOPLE_FILE, Path("salespeople.json")):
        try:
            p.write_text(json.dumps(data, indent=2))
            try:
                import os as _o, stat as _s
                _o.chmod(p, _s.S_IRUSR | _s.S_IWUSR)
            except Exception:
                pass
            return True
        except Exception:
            pass
    return False


def owner_salespeople():
    st.markdown("## Sales Representatives")
    st.caption("Track field reps and their locations")

    reps = load_salespeople()

    with st.expander("Add Salesperson", expanded=(len(reps) == 0)):
        with st.form("add_rep", clear_on_submit=True):
            c1, c2 = st.columns(2)
            with c1:
                name  = st.text_input("Full name *", placeholder="Ramesh Kumar")
                phone = st.text_input("Phone", placeholder="9876543210")
            with c2:
                area  = st.text_input("Assigned area", placeholder="Chennai North")
                city  = st.selectbox("Base city",
                    ["chennai", "coimbatore", "madurai", "trichy", "salem",
                     "thanjavur", "tirunelveli", "vellore"])
            if st.form_submit_button("Add", type="primary", use_container_width=True):
                if not name:
                    st.error("Name required.")
                else:
                    lat, lon, _ = _geocode(city)
                    reps.append({
                        "id": "REP" + str(len(reps) + 1).zfill(3),
                        "name": name, "phone": phone, "area": area,
                        "city": city, "lat": lat, "lon": lon,
                        "last_seen": datetime.now().strftime("%d-%b-%Y %H:%M"),
                        "visits_today": 0, "active": True,
                    })
                    if save_salespeople(reps):
                        st.success(name + " added")
                        st.rerun()

    if not reps:
        st.info("No salespeople yet. Add one above.")
        return

    st.markdown('<div class="section-head">Current Reps</div>', unsafe_allow_html=True)
    for i, r in enumerate(reps):
        c1, c2 = st.columns([3, 2])
        with c1:
            st.markdown(
                '<div class="bill-card" style="border-left-color:#7b61ff;">'
                '<div style="font-weight:700;color:#e8eaf6;">' + r.get("name", "-")
                + ' <span style="color:#8892b0;font-size:.72rem;">' + r.get("id", "-") + '</span></div>'
                '<div style="color:#c5cae9;font-size:.78rem;margin-top:.3rem;">'
                + r.get("phone", "-") + ' &middot; '
                + (r.get("area", "") or r.get("city", "").title()) + '</div>'
                '<div style="color:#8892b0;font-size:.7rem;margin-top:.2rem;">'
                'Last seen: ' + r.get("last_seen", "-") + '</div>'
                '</div>',
                unsafe_allow_html=True,
            )
        with c2:
            cities = ["chennai", "coimbatore", "madurai", "trichy", "salem",
                      "thanjavur", "tirunelveli", "vellore", "ooty", "hosur"]
            cur = r.get("city", "chennai")
            idx = cities.index(cur) if cur in cities else 0
            new_city = st.selectbox("Move to", cities, index=idx,
                                    key="city_" + str(i) + "_" + str(r.get("id", "x")))
            b1, b2 = st.columns(2)
            if b1.button("Check-in", key="ci_" + str(i) + "_" + str(r.get("id", "x")),
                         use_container_width=True):
                lat, lon, _ = _geocode(new_city)
                reps[i]["city"] = new_city
                reps[i]["lat"] = lat
                reps[i]["lon"] = lon
                reps[i]["last_seen"] = datetime.now().strftime("%d-%b-%Y %H:%M")
                reps[i]["visits_today"] = int(reps[i].get("visits_today", 0)) + 1
                if save_salespeople(reps):
                    st.rerun()
            if b2.button("Remove", key="rm_" + str(i) + "_" + str(r.get("id", "x")),
                         use_container_width=True):
                reps.pop(i)
                if save_salespeople(reps):
                    st.rerun()

    # ── Live map ──
    st.markdown('<div class="section-head">Live Rep Map</div>', unsafe_allow_html=True)
    import streamlit.components.v1 as components

    retailers = load_retailers()

    # Build marker JS using ONLY single quotes (no escaping needed)
    js_parts = []
    for rr in retailers:
        lat, lon, _ = _geocode(rr.get("address", ""))
        shop = str(rr.get("shop", "?")).replace("'", " ")
        owner = str(rr.get("owner", "")).replace("'", " ")
        js_parts.append(
            "L.circleMarker([" + str(lat) + "," + str(lon) + "],"
            "{radius:5,color:'#8892b0',fillColor:'#8892b0',fillOpacity:0.6,weight:1})"
            ".addTo(map).bindPopup('<b>" + shop + "</b><br>" + owner + "');"
        )
    for rr in reps:
        nm_safe = str(rr.get("name", "")).replace("'", " ")
        ph  = str(rr.get("phone", "-"))
        cty = str(rr.get("city", "")).title()
        seen = str(rr.get("last_seen", ""))
        label_html = (
            "<div style='background:#7b61ff;color:#fff;padding:5px 10px;"
            "border-radius:20px;font-weight:800;font-size:11px;"
            "border:2px solid #fff;white-space:nowrap;'>" + nm_safe + "</div>"
        )
        popup = nm_safe + " - " + ph + " - " + cty + " - " + seen
        # Escape only the double quotes for the JS attribute
        label_esc = label_html.replace('"', '\\"')
        js_parts.append(
            "L.marker([" + str(rr.get("lat")) + "," + str(rr.get("lon")) + "],"
            "{icon:L.divIcon({html:\"" + label_esc + "\","
            "iconSize:null,iconAnchor:[40,16],className:''})})"
            ".addTo(map).bindPopup('" + popup + "');"
        )

    markers_js = "".join(js_parts)

    html_map = (
        "<!DOCTYPE html><html><head><meta charset='utf-8'/>"
        "<link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'/>"
        "<script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script>"
        "<style>html,body{margin:0;padding:0;background:#0a0e1a;}#map{width:100%;height:460px;}"
        ".leaflet-popup-content-wrapper{background:#1a1f2e;color:#e8eaf6;border-radius:10px;}"
        ".leaflet-popup-tip{background:#1a1f2e;}</style></head>"
        "<body><div id='map'></div><script>"
        "var map = L.map('map').setView([11.1271,78.6569],7);"
        "L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}',{maxZoom:16}).addTo(map);"
        + markers_js +
        "</script></body></html>"
    )
    components.html(html_map, height=500, scrolling=False)


# ══════════════════════════════════════════════════════════════
#  OWNER COMMANDMENTS  (hybrid: hard floor + tunable ceiling)
# ══════════════════════════════════════════════════════════════
COMMANDMENTS_FILE = PARENT / "commandments.json"

# HARD floors — cannot be changed by anyone
COMMANDMENTS_HARD = {
    "block_at_100pct": True,           # over limit = blocked
    "block_aging_over_90": True,       # >90 days = suspended
    "log_every_write": True,           # immutable audit
    "no_retailer_export": True,        # retailers can't download
}

# SOFT rules — owner can tune
COMMANDMENTS_DEFAULT = {
    "soft_block_at_pct": 90,           # warn retailer at 90%+ (owner decides)
    "aging_soft_warn_days": 60,        # warn at 60 days
    "auto_flag_overdue": True,         # flag when aging passes 60
    "ai_assist_enabled": True,         # AI co-pilot for owner
}

def load_commandments():
    for p in (COMMANDMENTS_FILE, Path("commandments.json")):
        if p.exists():
            try:
                d = json.loads(p.read_text())
                return {**COMMANDMENTS_HARD, **COMMANDMENTS_DEFAULT, **d}
            except Exception: pass
    return {**COMMANDMENTS_HARD, **COMMANDMENTS_DEFAULT}

def save_commandments(data):
    for p in (COMMANDMENTS_FILE, Path("commandments.json")):
        try:
            p.write_text(json.dumps(data, indent=2))
            try:
                import os as _o, stat as _s
                _o.chmod(p, _s.S_IRUSR | _s.S_IWUSR)
            except Exception: pass
            return True
        except Exception: pass
    return False


def evaluate_credit_rule(retailer, cart_total):
    """Return (allowed, level, message).
       level: 'ok' | 'warn' | 'block'
    """
    cmd = load_commandments()
    limit = float((retailer or {}).get("credit_limit") or 0)
    out   = float((retailer or {}).get("outstanding") or 0)
    status = str((retailer or {}).get("status") or "").lower()

    # HARD: already on hold
    if "hold" in status or "suspend" in status:
        return False, "block", "Account on credit hold — clear dues to unlock."

    # HARD: over 100%
    if limit > 0:
        pct_after = ((out + cart_total) / limit) * 100
    else:
        pct_after = 999 if (out + cart_total) > 0 else 0

    if cmd.get("block_at_100pct") and pct_after > 100:
        return False, "block", f"Order would push you to {pct_after:.0f}% of credit limit (₹{limit:,.0f})."

    # SOFT: over soft threshold
    soft = cmd.get("soft_block_at_pct", 90)
    if pct_after >= soft:
        return True, "warn", f"At {pct_after:.0f}% of credit limit after this order — owner will review."

    return True, "ok", ""

def owner_commandments():
    """Owner Commandments — hard rules + tunable policies."""
    st.markdown("## 📜 Owner Commandments")
    st.caption("Business rules the app enforces. Hard floors cannot be changed.")

    cmd = load_commandments()

    # ── HARD rules (read-only) ──
    st.markdown('<div class="section-head">🔒 Hard Rules (unchangeable)</div>',
                unsafe_allow_html=True)
    hard_items = [
        ("Block at 100% of credit limit", "block_at_100pct"),
        ("Block aging over 90 days", "block_aging_over_90"),
        ("Audit every write", "log_every_write"),
        ("Retailers cannot export data", "no_retailer_export"),
    ]
    for label, key in hard_items:
        state = "✅ Enforced" if COMMANDMENTS_HARD.get(key) else "❌ Disabled"
        st.markdown(
            f'<div class="bill-card" style="border-left-color:#00d47a;">'
            f'<div style="display:flex;justify-content:space-between;align-items:center;">'
            f'<div style="color:#e8eaf6;font-weight:600;">{label}</div>'
            f'<div style="color:#00d47a;font-size:.8rem;font-weight:700;">{state}</div>'
            f'</div></div>',
            unsafe_allow_html=True
        )

    # ── SOFT rules (editable) ──
    st.markdown('<div class="section-head">⚙️ Tunable Policies</div>',
                unsafe_allow_html=True)

    c1, c2 = st.columns(2)
    with c1:
        cmd["soft_block_at_pct"] = st.slider(
            "Warn retailer at (% of credit used)",
            min_value=50, max_value=100,
            value=int(cmd.get("soft_block_at_pct", 90)),
            help="Between this and 100%, order is allowed but flagged for review.",
        )
    with c2:
        cmd["aging_soft_warn_days"] = st.slider(
            "Aging soft warn (days)",
            min_value=15, max_value=90, step=5,
            value=int(cmd.get("aging_soft_warn_days", 60)),
            help="Retailers with invoices older than this get a warning.",
        )

    c3, c4 = st.columns(2)
    with c3:
        cmd["auto_flag_overdue"] = st.toggle(
            "Auto-flag overdue retailers",
            value=bool(cmd.get("auto_flag_overdue", True)),
        )
    with c4:
        cmd["ai_assist_enabled"] = st.toggle(
            "Enable AI co-pilot suggestions",
            value=bool(cmd.get("ai_assist_enabled", True)),
            help="JARVIS analyzes retailers and gives you decision support.",
        )

    # Save
    st.markdown("---")
    c5, c6 = st.columns(2)
    with c5:
        if st.button("💾 Save Policies", type="primary", use_container_width=True):
            if save_commandments(cmd):
                st.success("✅ Saved.")
                st.rerun()
    with c6:
        if st.button("↩️ Reset to Defaults", use_container_width=True):
            save_commandments(dict(COMMANDMENTS_HARD, **COMMANDMENTS_DEFAULT))
            st.rerun()

    # Live preview
    st.markdown('<div class="section-head">👁️ Live Preview</div>',
                unsafe_allow_html=True)
    st.markdown(
        f'<div class="bill-card"><div style="font-size:.85rem;line-height:1.9;color:#e8eaf6;">'
        f'<b>Warn threshold:</b> {cmd.get("soft_block_at_pct", 90)}% credit used<br>'
        f'<b>Hard block:</b> >100% credit<br>'
        f'<b>Aging warn:</b> {cmd.get("aging_soft_warn_days", 60)} days<br>'
        f'<b>Aging hard:</b> >90 days (frozen)<br>'
        f'<b>AI assist:</b> {"On" if cmd.get("ai_assist_enabled") else "Off"}'
        f'</div></div>',
        unsafe_allow_html=True
    )


def owner_ai_analyzer():
    """AI co-pilot: analyzes every retailer, ranks risk, suggests action."""
    st.markdown("## 🧠 AI Co-Pilot — Retailer Analyzer")
    st.caption("Reads live data, ranks every retailer, tells you who needs attention")

    rets = load_retailers()
    orders = load_orders()
    if not rets:
        st.warning("No retailers."); return

    # ── Local analysis first (works without Groq) ──
    rows = []
    for r in rets:
        rid = r.get("id", "?")
        shop = r.get("shop", "?")
        lim = float(r.get("credit_limit") or 0)
        out = float(r.get("outstanding") or 0)
        status = str(r.get("status") or "Active")
        my = [o for o in orders if str(o.get("retailer_id","")).upper() == rid.upper()]
        # Last order
        last_dt = None
        for o in my:
            try:
                d = pd.to_datetime(o.get("placed_at"), errors="coerce", format="mixed")
                if pd.notna(d) and (last_dt is None or d > last_dt):
                    last_dt = d
            except Exception: pass
        days_since = (datetime.now() - last_dt).days if last_dt else 999
        pct = (out / lim * 100) if lim else 0

        # Risk score: 0 = safe, 100 = danger
        risk = 0
        risk += min(pct, 100) * 0.5              # credit usage (0-50)
        risk += min(days_since / 2, 30)          # staleness (0-30)
        risk += 10 if "hold" in status.lower() else 0
        risk += 10 if out > 100000 else 0
        risk = min(risk, 100)

        # Recommendation (rule-based)
        if "hold" in status.lower():
            action = "🔒 Frozen — awaiting payment. Call to discuss."
            urgency = "critical"
        elif pct >= 100:
            action = f"🚫 Over limit by ₹{out-lim:,.0f}. Freeze now."
            urgency = "critical"
        elif pct >= 90:
            action = f"⚠️ At {pct:.0f}% credit. Call before next order."
            urgency = "high"
        elif days_since > 90:
            action = f"😴 Dormant {days_since} days. Re-engagement call."
            urgency = "high"
        elif days_since > 60:
            action = f"🕐 No order in {days_since} days. Send offer."
            urgency = "medium"
        elif out > 50000 and days_since <= 30:
            action = f"💰 Active but high balance (₹{out:,.0f}). Friendly reminder."
            urgency = "medium"
        else:
            action = f"✅ Healthy. Last order {days_since} days ago."
            urgency = "ok"

        rows.append({
            "ID": rid, "Shop": shop,
            "Limit": lim, "Outstanding": out,
            "Used%": round(pct, 1),
            "Days Since": days_since,
            "Status": status,
            "Risk": round(risk, 1),
            "Urgency": urgency,
            "Action": action,
        })

    df = pd.DataFrame(rows).sort_values("Risk", ascending=False)

    # ── Hero ──
    critical = df[df["Urgency"] == "critical"]
    high = df[df["Urgency"] == "high"]
    medium = df[df["Urgency"] == "medium"]
    ok = df[df["Urgency"] == "ok"]

    st.markdown(f"""
    <div class="hero">
        <div class="hero-eyebrow">🧠 AI CO-PILOT</div>
        <h1>Your attention is needed on <span class="accent">{len(critical) + len(high)}</span> retailers</h1>
        <p>Ranked by risk. Highest priority first.</p>
        <div class="hero-stats">
            <div><div class="hero-stat-label">🔴 Critical</div><div class="hero-stat-value">{len(critical)}</div></div>
            <div><div class="hero-stat-label">🟠 High</div><div class="hero-stat-value">{len(high)}</div></div>
            <div><div class="hero-stat-label">🟡 Medium</div><div class="hero-stat-value">{len(medium)}</div></div>
            <div><div class="hero-stat-label">✅ Healthy</div><div class="hero-stat-value">{len(ok)}</div></div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # ── Ranked action list ──
    st.markdown('<div class="section-head">📋 Owner Action List</div>', unsafe_allow_html=True)
    urgency_color = {"critical": "#ff4d6d", "high": "#ffb547",
                     "medium": "#00d4ff", "ok": "#00d47a"}
    urgency_icon = {"critical": "🔴", "high": "🟠", "medium": "🟡", "ok": "✅"}

    for i, r in df.head(15).iterrows():
        col = urgency_color[r["Urgency"]]
        icon = urgency_icon[r["Urgency"]]
        st.markdown(f"""
        <div class="bill-card" style="border-left-color:{col};">
            <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:.6rem;">
                <div style="flex:1;min-width:180px;">
                    <div style="font-weight:700;color:#e8eaf6;">{icon} {r['Shop']} <span style="color:#8892b0;font-size:.72rem;">{r['ID']}</span></div>
                    <div style="color:#c5cae9;font-size:.78rem;margin-top:.3rem;">{r['Action']}</div>
                </div>
                <div style="text-align:right;">
                    <div style="color:{col};font-weight:800;font-size:1.05rem;">Risk {r['Risk']}</div>
                    <div style="color:#8892b0;font-size:.7rem;">₹{r['Outstanding']:,.0f} / ₹{r['Limit']:,.0f}</div>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)

    # ── Full table ──
    with st.expander("📊 Full Retailer Analysis Table"):
        st.dataframe(df, use_container_width=True, hide_index=True)
        csv = df.to_csv(index=False)
        st.download_button("📥 Download Analysis (CSV)", data=csv,
                           file_name=f"ai_analysis_{datetime.now():%Y%m%d}.csv",
                           mime="text/csv", use_container_width=True)

    # ── Groq-powered deeper analysis (if key exists) ──
    if cmd_ai_enabled():
        st.markdown('<div class="section-head">🤖 AI Deep Dive (Powered by Groq)</div>',
                    unsafe_allow_html=True)
        st.caption("Ask AI to reason about your retailers in natural language")
        q = st.text_input("Your question",
                          placeholder="e.g. Which retailers should I freeze this week?",
                          key="ai_analyzer_q").strip()
        if q:
            with st.spinner("AI is analyzing your data..."):
                ctx = _build_business_context()
                reply = _groq_ask(q, ctx)
            if reply:
                st.markdown(f'<div class="chat-bot">{reply}</div>', unsafe_allow_html=True)
            else:
                st.info("Set your Groq key to enable AI answers. See .groq_key instructions.")


def cmd_ai_enabled():
    try:
        return load_commandments().get("ai_assist_enabled", True)
    except Exception:
        return True


def inject_security_headers():
    """Inject CSP + frame protection via HTML meta tags (server headers
    aren't settable from Streamlit, but meta tags help in browsers)."""
    st.markdown(
        '<meta http-equiv="X-Content-Type-Options" content="nosniff">'
        '<meta http-equiv="X-Frame-Options" content="SAMEORIGIN">'
        '<meta name="referrer" content="no-referrer">'
        '<meta http-equiv="Permissions-Policy" content="geolocation=(), camera=(), microphone=()">',
        unsafe_allow_html=True
    )


def _groq_ask(question, context):
    """Send a question + business context to Groq. Returns string reply or None."""
    try:
        import urllib.request
        key = ""
        for p in (PARENT / ".groq_key", Path(".groq_key")):
            if p.exists():
                key = p.read_text().strip()
                break
        if not key or not key.startswith("gsk_"):
            return None

        payload = {
            "model": "openai/gpt-oss-120b",
            "messages": [
                {"role": "system",
                 "content": "You are JARVIS, AI assistant for Meena Agencies, "
                            "a wholesale pharma distributor in Tamil Nadu, India. "
                            "Answer concisely using the live data. Be specific with "
                            "numbers. Use Rs. for amounts. Never invent data."},
                {"role": "system", "content": "LIVE DATA:\n" + context},
                {"role": "user",   "content": question},
            ],
            "temperature": 0.3,
            "max_tokens": 700,
        }
        req = urllib.request.Request(
            "https://api.groq.com/openai/v1/chat/completions",
            data=json.dumps(payload).encode(),
            headers={
                "Authorization": "Bearer " + key,
                "Content-Type": "application/json",
                "User-Agent": "Meena/1.0 (+local)",
                "Accept": "application/json",
            },
        )
        with urllib.request.urlopen(req, timeout=25) as resp:
            data = json.loads(resp.read())
            return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        return "Groq error: " + str(e)


def _build_business_context():
    """Snapshot of live business data for the AI model."""
    try:
        orders = load_orders()
        rets = load_retailers()
        inv = load_inventory()
        lines = []
        lines.append("=== BUSINESS SNAPSHOT ===")
        lines.append(f"Total orders: {len(orders)}")
        pend = [o for o in orders if (o.get("status") or "").lower() == "pending"]
        lines.append(f"Pending orders: {len(pend)} (worth Rs.{sum(float(o.get('total',0)) for o in pend):,.0f})")
        lines.append("")
        lines.append("=== RETAILERS ===")
        for r in rets:
            lines.append(
                f"- {r.get('shop','?')} ({r.get('id','?')}): "
                f"owner={r.get('owner','?')}, "
                f"outstanding=Rs.{float(r.get('outstanding') or 0):,.0f}, "
                f"limit=Rs.{float(r.get('credit_limit') or 0):,.0f}, "
                f"status={r.get('status','Active')}"
            )
        if not inv.empty:
            lines.append("")
            lines.append(f"=== INVENTORY === {len(inv)} rows in stock")
        return "\n".join(lines)
    except Exception as e:
        return f"(context build error: {e})"


def owner_payments():
    """Record + view retailer payments."""
    st.markdown("## 💰 Payments")
    st.caption("Record payments — cash, bank, cheque, UPI. Track partial payments.")

    if not B1_LOADED:
        st.error("Payments module not loaded: " + globals().get("_B1_ERR","?"))
        return

    rets = load_retailers()

    # ══════════════════════════════════════════════════
    # RECORD PAYMENT
    # ══════════════════════════════════════════════════
    st.markdown('<div class="section-head">➕ Record Payment</div>', unsafe_allow_html=True)

    with st.form("record_pay", clear_on_submit=True):
        c1, c2 = st.columns(2)
        with c1:
            options = []
            for r in rets:
                out = float(r.get("outstanding") or 0)
                options.append((r.get("id"), f"{r.get('id')} - {r.get('shop','?')} (owes Rs.{out:,.0f})"))
            sel = st.selectbox("Retailer", options, format_func=lambda x: x[1] if isinstance(x, tuple) else x)
            rid = sel[0] if isinstance(sel, tuple) else sel
            amount = st.number_input("Amount (Rs.)", min_value=0.0, step=1000.0, format="%.2f")
            date = st.date_input("Date", value=datetime.now().date())
        with c2:
            method = st.selectbox("Method", ["Cash", "Bank Transfer", "Cheque", "UPI", "NEFT", "RTGS", "DD"])
            reference = st.text_input("Reference #", placeholder="CHQ-847291 / UPI ref / NEFT utr")
            notes = st.text_input("Notes (optional)", placeholder="First installment of Rs.1L")
            pending = st.checkbox("Pending clearance (for cheques)", value=False)

        if st.form_submit_button("💾 Save Payment", type="primary", use_container_width=True):
            if amount <= 0:
                st.error("Amount must be > 0")
            else:
                status = "pending_clearance" if pending else "cleared"
                rec = b1.record_payment(rid, amount, method, reference, notes,
                                        date.strftime("%Y-%m-%d"), status)
                st.success(f"✅ Payment {rec['payment_id']} recorded — Rs.{amount:,.0f} via {method}")
                try:
                    from datetime import datetime as _dt
                    body = (f"Payment received: <b>Rs.{amount:,.0f}</b>\n"
                            f"Method: {method}\n"
                            f"Reference: {reference or 'N/A'}\n"
                            f"Date: {date}\n"
                            f"Notes: {notes or '-'}")
                    b1._send_telegram(b1.build_telegram_message(rid, body))
                except Exception: pass
                st.cache_data.clear()
                st.rerun()

    # ══════════════════════════════════════════════════
    # PENDING CLEARANCES
    # ══════════════════════════════════════════════════
    payments = b1.load_payments()
    pending_pays = [p for p in payments if p.get("status") == "pending_clearance"]

    if pending_pays:
        st.markdown('<div class="section-head">⏳ Pending Clearance</div>', unsafe_allow_html=True)
        for p in pending_pays:
            c1, c2, c3 = st.columns([3, 1, 1])
            with c1:
                st.markdown(f"**{p['payment_id']}** · {p['retailer_id']} · Rs.{p['amount']:,.0f} · {p['method']} ({p['reference']})")
            with c2:
                if st.button("✅ Cleared", key=f"clr_{p['payment_id']}", use_container_width=True):
                    b1.clear_pending_payment(p["payment_id"])
                    st.cache_data.clear(); st.rerun()
            with c3:
                if st.button("❌ Bounced", key=f"bnc_{p['payment_id']}", use_container_width=True):
                    b1.mark_bounced(p["payment_id"])
                    st.cache_data.clear(); st.rerun()

    # ══════════════════════════════════════════════════
    # PAYMENT HISTORY
    # ══════════════════════════════════════════════════
    st.markdown('<div class="section-head">📜 Payment History</div>', unsafe_allow_html=True)

    if not payments:
        st.info("No payments recorded yet.")
        return

    c1, c2 = st.columns(2)
    with c1:
        filter_rid = st.selectbox("Filter retailer", ["All"] + sorted(set(p.get("retailer_id","") for p in payments)))
    with c2:
        filter_method = st.selectbox("Filter method", ["All"] + sorted(set(p.get("method","") for p in payments)))

    view = payments
    if filter_rid != "All":
        view = [p for p in view if p.get("retailer_id") == filter_rid]
    if filter_method != "All":
        view = [p for p in view if p.get("method") == filter_method]

    # Summary tiles
    total_cleared = sum(float(p["amount"]) for p in view if p.get("status") == "cleared")
    total_pending = sum(float(p["amount"]) for p in view if p.get("status") == "pending_clearance")
    total_bounced = sum(float(p["amount"]) for p in view if p.get("status") == "bounced")

    m1, m2, m3 = st.columns(3)
    with m1:
        st.markdown(f'<div class="metric-tile green"><div class="label">Cleared</div><div class="value">Rs.{total_cleared:,.0f}</div><div style="font-size:.7rem;color:#8892b0;margin-top:.3rem;">{len([p for p in view if p.get("status")=="cleared"])} payments</div></div>', unsafe_allow_html=True)
    with m2:
        st.markdown(f'<div class="metric-tile orange"><div class="label">Pending</div><div class="value">Rs.{total_pending:,.0f}</div></div>', unsafe_allow_html=True)
    with m3:
        st.markdown(f'<div class="metric-tile red"><div class="label">Bounced</div><div class="value">Rs.{total_bounced:,.0f}</div></div>', unsafe_allow_html=True)

    # Table
    rows = []
    for p in reversed(view[-100:]):
        rows.append({
            "ID": p.get("payment_id",""),
            "Date": p.get("date",""),
            "Retailer": p.get("retailer_id",""),
            "Amount": f"Rs.{p.get('amount',0):,.0f}",
            "Method": p.get("method",""),
            "Reference": p.get("reference",""),
            "Status": p.get("status",""),
            "Notes": p.get("notes",""),
            "Recorded": p.get("recorded_at",""),
        })
    if rows:
        st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True, height=400)
        csv = pd.DataFrame(rows).to_csv(index=False)
        st.download_button("📥 Download Payments (CSV)", data=csv,
                           file_name=f"payments_{datetime.now():%Y%m%d}.csv",
                           mime="text/csv", use_container_width=True)


def owner_permissions():
    """Permission Queue — approve/reject AI actions."""
    st.markdown("## 🔐 AI Permission Queue")
    st.caption("Every AI action waits here for your approval. Nothing sends without YES.")

    if not PERMS_LOADED:
        st.error("Permissions module not loaded: " + globals().get("_PERMS_ERR", "?"))
        return

    # ── Run detectors button ──
    c1, c2, c3 = st.columns([1, 1, 2])
    with c1:
        if st.button("🔍 Scan for Actions", type="primary", use_container_width=True):
            with st.spinner("AI analyzing your business..."):
                results = perms.run_all_detectors()
            st.success(f"✅ Detected: {results}")
            st.rerun()
    with c2:
        if st.button("📊 View Today", use_container_width=True):
            st.info("Scroll down to see the full queue.")

    # ── Pending actions ──
    pending = perms.get_pending()

    if not pending:
        st.info("✅ No pending actions. AI is watching for opportunities.")
    else:
        st.warning(f"⚠️ **{len(pending)}** action(s) awaiting your decision")

        # Bulk actions
        c1, c2 = st.columns([1, 1])
        with c1:
            if st.button(f"✅ Approve ALL ({len(pending)})", type="primary", use_container_width=True):
                for a in pending:
                    perms.approve_action(a["id"], executor=perms.execute_send_message)
                st.success(f"Approved {len(pending)} action(s)"); st.rerun()
        with c2:
            if st.button("❌ Reject ALL", use_container_width=True):
                for a in pending:
                    perms.reject_action(a["id"], reason="Bulk reject")
                st.info(f"Rejected {len(pending)} action(s)"); st.rerun()

        # Individual actions
        sev_color = {"info": "#00d4ff", "warn": "#ffb547", "critical": "#ff4d6d"}
        sev_icon = {"info": "💡", "warn": "⚠️", "critical": "🚨"}

        for a in pending:
            color = sev_color.get(a.get("severity", "info"), "#00d4ff")
            icon = sev_icon.get(a.get("severity", "info"), "💡")
            st.markdown(f"""
            <div class="bill-card" style="border-left-color:{color};">
                <div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:.5rem;">
                    <div style="flex:1;min-width:200px;">
                        <div style="font-weight:700;color:#e8eaf6;">{icon} {a.get('summary','')}</div>
                        <div style="color:#8892b0;font-size:.72rem;margin-top:.3rem;">
                            Type: <b>{a.get('type','')}</b> · Created: {a.get('created_at','')}
                        </div>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)

            # Preview message
            payload = a.get("payload", {})
            if "message" in payload:
                with st.expander("👁️ Preview message"):
                    st.text(payload["message"])

            c1, c2 = st.columns(2)
            with c1:
                if st.button("✅ Approve & Send", key=f"ap_{a['id']}",
                             type="primary", use_container_width=True):
                    perms.approve_action(a["id"], executor=perms.execute_send_message)
                    st.success(f"✅ Sent to {payload.get('shop','?')}")
                    st.rerun()
            with c2:
                if st.button("❌ Reject", key=f"rj_{a['id']}", use_container_width=True):
                    perms.reject_action(a["id"], reason="Manual reject")
                    st.info("Rejected")
                    st.rerun()

    # ── History ──
    st.markdown("---")
    st.markdown('<div class="section-head">📜 Recent Decisions</div>', unsafe_allow_html=True)
    all_actions = [a for a in perms.get_all() if a.get("status") != "pending"]
    if not all_actions:
        st.caption("No decisions yet.")
    else:
        history_rows = [{
            "When": a.get("resolved_at", a.get("created_at", "")),
            "Type": a.get("type", ""),
            "Summary": a.get("summary", ""),
            "Status": a.get("status", ""),
            "By": a.get("resolved_by", a.get("rejected_by", "")),
        } for a in all_actions[-50:]]
        st.dataframe(pd.DataFrame(history_rows), use_container_width=True, hide_index=True, height=300)


def owner_placeholder(label, icon="⏳"):
    st.markdown(f"## {icon} {label}")
    st.info("Coming soon.")


# ═══════════════════════════════════════════════════════════
#  RETAILER PAGES
# ═══════════════════════════════════════════════════════════
CATEGORIES = ["Antibiotic","Pain Relief","Cardiac","Diabetes","Gastro",
              "Allergy","Injection","Syrup","Inhaler","Powder"]

def _classify(name):
    n = name.lower()
    if "inhal" in n: return "🌬️","#7b61ff","Inhaler"
    if "syrup" in n or "cough" in n: return "🧴","#00d4ff","Syrup"
    if "powder" in n or "ors" in n: return "🥤","#ffb547","Powder"
    if "insulin" in n or "inject" in n: return "💉","#ff4d6d","Injection"
    if "amoxi" in n or "azithro" in n: return "💊","#ff8c42","Antibiotic"
    if "metfor" in n: return "🩸","#ff4d6d","Diabetes"
    if "atorva" in n: return "❤️","#e91e63","Cardiac"
    if "paracet" in n or "ibupro" in n: return "💊","#00d4ff","Pain Relief"
    if "cetiri" in n: return "🤧","#7b61ff","Allergy"
    if "omepra" in n: return "🫃","#00d47a","Gastro"
    return "💊","#00d4ff","Medicine"

@st.cache_data(ttl=10)
def order_catalog():
    raw = load_inventory()
    if raw.empty: return pd.DataFrame()
    df = raw.copy()
    nm = find_col(df,"medicine_name","medicine","name")
    pr = find_col(df,"cost_price","price","mrp","rate")
    stk= find_col(df,"quantity","stock","qty")
    if not nm: return pd.DataFrame()
    out = pd.DataFrame()
    out["name"] = df[nm].astype(str).str.strip()
    out["price"] = pd.to_numeric(df[pr],errors="coerce").fillna(0) if pr else 0.0
    out["stock"] = pd.to_numeric(df[stk],errors="coerce").fillna(0).astype(int) if stk else 0
    if pr and pr.lower()=="cost_price":
        out["price"] = (out["price"]*1.18).round(2)
    g = out.groupby("name",as_index=False).agg(price=("price","min"),stock=("stock","sum"),batches=("name","count"))
    g["emoji"],g["color"],g["cat"] = zip(*g["name"].map(_classify))
    return g.sort_values("name").reset_index(drop=True)


def retailer_home():
    r = st.session_state.retailer
    name = r.get("owner") or r.get("shop") or st.session_state.retailer_id
    shop = r.get("shop","")
    rid = st.session_state.retailer_id
    lim = float(r.get("credit_limit") or 0)
    out = float(r.get("outstanding") or 0)
    av  = lim - out

    st.markdown(f"""
    <div class="hero">
        <div class="hero-eyebrow">🏪 RETAILER · {rid}</div>
        <h1>Welcome back, <span class="accent">{name}</span></h1>
        <p>Order medicines and manage your account for <b>{shop}</b>.</p>
        <div class="hero-stats">
            <div><div class="hero-stat-label">Credit Limit</div><div class="hero-stat-value">{money(lim)}</div></div>
            <div><div class="hero-stat-label">Outstanding</div><div class="hero-stat-value">{money(out)}</div></div>
            <div><div class="hero-stat-label">Available</div><div class="hero-stat-value">{money(av)}</div></div>
        </div>
    </div>""", unsafe_allow_html=True)

    orders = [o for o in load_orders() if str(o.get("retailer_id","")).upper()==rid]
    m1,m2,m3,m4 = st.columns(4)
    for col,tone,label,val,sub in [
        (m1,"cyan","Total Orders",str(len(orders)),"all time"),
        (m2,"purple","Total Spent",money(sum(float(o.get("total",0)) for o in orders)),"lifetime"),
        (m3,"green","Avg Order",money(sum(float(o.get("total",0)) for o in orders)/len(orders) if orders else 0),"per order"),
        (m4,"orange","Last Order",(orders[0].get("placed_at","—")[:11] if orders else "—"),""),
    ]:
        with col:
            st.markdown(f'<div class="metric-tile {tone}"><div class="label">{label}</div><div class="value">{val}</div><div style="font-size:.68rem;color:#8892b0;margin-top:.3rem;">{sub}</div></div>', unsafe_allow_html=True)

    st.markdown('<div class="section-head">⚡ Quick Actions</div>', unsafe_allow_html=True)
    q1,q2,q3,q4 = st.columns(4)
    with q1:
        if st.button("🛒 Place Order", use_container_width=True, key="rq_order"):
            st.session_state.page="order"; st.rerun()
    with q2:
        if st.button("🔍 Stock Check", use_container_width=True, key="rq_stock"):
            st.session_state.page="stock"; st.rerun()
    with q3:
        if st.button("🧾 My Bills", use_container_width=True, key="rq_bills"):
            st.session_state.page="bills"; st.rerun()
    with q4:
        if st.button("💰 My Ledger", use_container_width=True, key="rq_led"):
            st.session_state.page="ledger"; st.rerun()


def retailer_order():
    st.markdown("## 🛒 Place Order")
    df = order_catalog()
    if df.empty: st.error("No inventory."); return

    st.session_state.setdefault("cart",[])
    st.session_state.setdefault("cat_open", None)

    if st.session_state.cat_open:
        cat = st.session_state.cat_open
        if st.button("← All Categories", key="backc"): st.session_state.cat_open=None; st.rerun()
        st.markdown(f'<div class="section-head">{cat}</div>', unsafe_allow_html=True)
        view = df[df["cat"]==cat]
        cols = st.columns(3)
        for i,(_,row) in enumerate(view.iterrows()):
            with cols[i%3]: _r_med_card(row)
    else:
        st.markdown('<div class="section-head">Browse by Category</div>', unsafe_allow_html=True)
        q = st.text_input("Search all medicines", placeholder="Type a name…",
                          key="rq_search", label_visibility="collapsed").strip().lower()
        if q:
            m = df[df["name"].str.lower().str.contains(q,na=False)].head(60)
            st.caption(f"{len(m)} result(s)")
            cols = st.columns(3)
            for i,(_,row) in enumerate(m.iterrows()):
                with cols[i%3]: _r_med_card(row)
        else:
            cols = st.columns(3)
            for i,cat in enumerate(CATEGORIES):
                sub = df[df["cat"]==cat]
                emoji,color,_ = _classify(cat)
                with cols[i%3]:
                    st.markdown(f'<div class="med-card" style="border-top:3px solid {color};"><div class="med-emoji">{emoji}</div><div class="med-name">{cat}</div><div class="med-meta">{len(sub)} medicine(s) · {int(sub["stock"].sum()):,} units</div></div>', unsafe_allow_html=True)
                    if st.button("Open →", key=f"oc_{cat}", use_container_width=True):
                        st.session_state.cat_open=cat; st.rerun()
    _r_cart()


def _r_med_card(row):
    color = row["color"]
    st.markdown(f'<div class="med-card" style="border-top:3px solid {color};"><div class="med-emoji">{row["emoji"]}</div><div class="med-name">{row["name"][:36]}</div><div class="med-price" style="color:{color};">₹{row["price"]:,.2f}</div><div class="med-meta">{int(row["batches"])} batch(es) · {int(row["stock"]):,} in stock</div></div>', unsafe_allow_html=True)
    if int(row["stock"])<=0:
        st.button("Out of stock", key=f"oos_{row['name']}", disabled=True, use_container_width=True); return
    q1,q2 = st.columns([1,2])
    with q1:
        qty = st.number_input("Q", min_value=1, max_value=int(row["stock"]),
                              value=1, key=f"q_{row['name']}", label_visibility="collapsed")
    with q2:
        if st.button("➕ Add", key=f"add_{row['name']}", use_container_width=True, type="primary"):
            for line in st.session_state.cart:
                if line["name"]==row["name"]: line["qty"]+=qty; break
            else: st.session_state.cart.append({"name":row["name"],"price":float(row["price"]),"qty":qty})
            st.toast(f"Added {qty} × {row['name']}"); st.rerun()


def place_order_with_approval(retailer, cart):
    """Create order, evaluate credit rule, save to orders.json."""
    if not cart:
        return None
    total = sum(float(l["price"]) * int(l["qty"]) for l in cart)

    order = {
        "order_id": f"ORD-{datetime.now():%Y%m%d%H%M%S}",
        "retailer_id": st.session_state.get("retailer_id", ""),
        "shop": (retailer or {}).get("shop", ""),
        "placed_at": datetime.now().strftime("%d-%b-%Y %H:%M"),
        "total": round(total, 2),
        "items": [{
            "medicine": l["name"],
            "qty": int(l["qty"]),
            "price": float(l["price"]),
            "line_total": round(float(l["price"]) * int(l["qty"]), 2),
        } for l in cart],
        "status": "pending",
    }

    try:
        orders = load_orders()

        # Count prior orders for this retailer (for trusted-customer rule)
        prior = sum(1 for o in orders
                    if str(o.get("retailer_id", "")).upper()
                    == str(order["retailer_id"]).upper())

        # Credit rule check (Owner Commandments)
        allowed, level, msg = evaluate_credit_rule(retailer or {}, total)

        if not allowed:
            order["status"] = "blocked"
            order["approval_decision"] = "blocked"
            order["approval_reason"] = msg
        else:
            # Try the rules engine if it exists
            try:
                rules = load_rules()
                r_info = dict(retailer or {})
                r_info["_order_count"] = prior
                decision, reason, approver = decide_approval(order, r_info, rules)
                order["approval_decision"] = decision
                order["approval_reason"] = reason
                if decision == "auto":
                    order["status"] = "approved"
                    order["approved_by"] = approver or "System (auto)"
                    order["approved_at"] = datetime.now().strftime("%d-%b-%Y %H:%M")
                else:
                    order["approved_by"] = None
                    order["approved_at"] = None
            except Exception:
                # Fallback rule if decide_approval is missing
                order["approval_decision"] = "manual"
                order["approval_reason"] = "Queued for owner review"
                order["approved_by"] = None
                order["approved_at"] = None

            # Flag if over 90% credit
            try:
                lim = float((retailer or {}).get("credit_limit") or 0)
                out = float((retailer or {}).get("outstanding") or 0)
                if lim > 0 and (out + total) / lim >= 0.9:
                    order["flag"] = "OVER_LIMIT_REVIEW"
                    order["flag_reason"] = f"Uses {(out+total)/lim*100:.0f}% of credit"
            except Exception:
                pass

        orders.append(order)
        save_orders(orders)
    except Exception as e:
        order["approval_decision"] = "manual"
        order["approval_reason"] = f"Auto-approval error: {e}"

    return order


def _r_cart():
    cart = st.session_state.get("cart",[])
    if not cart: return
    total = sum(l["price"]*l["qty"] for l in cart)
    count = sum(l["qty"] for l in cart)
    st.markdown("---")
    st.markdown(f'<div class="section-head">🧺 Cart — {count} item(s) · {money(total)}</div>', unsafe_allow_html=True)
    for i,line in enumerate(list(cart)):
        c1,c2,c3,c4 = st.columns([4,2,2,1])
        c1.markdown(f"**{line['name']}**")
        c2.markdown(f"₹{line['price']:,.2f} × {line['qty']}")
        c3.markdown(f"**₹{line['price']*line['qty']:,.2f}**")
        if c4.button("✕", key=f"rm_{i}_{line['name']}"):
            cart.pop(i); st.rerun()
    # ─── Credit rule check (Owner Commandment) ───
    _rtr = st.session_state.get("retailer") or {}
    _allowed, _level, _msg = evaluate_credit_rule(_rtr, total)
    if _level == "warn":
        st.warning("⚠️ " + _msg + "  Order will be **flagged for owner review**.")
    elif _level == "block":
        st.error("🚫 " + _msg + "  **Submission blocked.**")

    if not _allowed:
        st.button("🚫 Cannot Submit — Credit Hold", type="primary",
                  use_container_width=True, disabled=True)
    else:
        if not st.session_state.get("otp_sent_for_cart"):
            b1col, b2col = st.columns(2)
            if b1col.button("🔐 Request OTP to Submit", type="primary", use_container_width=True):
                if OTP_LOADED:
                    rid = st.session_state.get("retailer_id", "")
                    shop = _rtr.get("shop", rid)
                    code = otp_mod.generate_otp(rid, {"total": total})
                    ok, msg = otp_mod.send_otp_telegram(rid, shop, code, total, count)
                    if ok:
                        st.session_state.otp_sent_for_cart = True
                        st.success("📱 OTP sent to your Telegram. Check your chat.")
                        st.rerun()
                    else:
                        st.error(f"Failed to send OTP: {msg}")
                else:
                    st.error("OTP module not loaded.")
            if b2col.button("🗑️ Clear Cart", use_container_width=True):
                st.session_state.cart = []
                st.rerun()
        else:
            st.info("📱 OTP sent. Enter the 6-digit code from Telegram.")
            otp_input = st.text_input("Enter OTP", max_chars=6, key="otp_code_input")
            vc1, vc2 = st.columns(2)
            with vc1:
                if st.button("✅ Verify & Submit", type="primary", use_container_width=True):
                    if OTP_LOADED:
                        rid = st.session_state.get("retailer_id", "")
                        ok, msg, payload = otp_mod.verify_otp(rid, otp_input)
                        if not ok:
                            st.error(msg)
                        else:
                            order = place_order_with_approval(st.session_state.get("retailer"), st.session_state.cart)
                            if order:
                                try:
                                    otp_mod.notify_order_placed(order)
                                except Exception:
                                    pass
                                d = order.get("approval_decision", "manual")
                                if d == "auto":
                                    st.success(f"✅ Order {order['order_id']} auto-approved")
                                else:
                                    st.warning(f"⏳ Order {order['order_id']} pending owner approval")
                                st.session_state.cart = []
                                st.session_state.otp_sent_for_cart = False
                                st.session_state.pop("otp_code_input", None)
                                st.rerun()
                    else:
                        st.error("OTP module not loaded.")
            with vc2:
                if st.button("↩️ Cancel / New OTP", use_container_width=True):
                    st.session_state.otp_sent_for_cart = False
                    st.session_state.pop("otp_code_input", None)
                    st.rerun()


def retailer_stock():
    st.markdown("## 🔍 Stock Check")
    df = order_catalog()
    if df.empty: st.error("No inventory."); return
    q = st.text_input("Search", placeholder="Type medicine…", key="rs_q",
                      label_visibility="collapsed").strip().lower()
    if not q: st.caption("Type to search…"); return
    v = df[df["name"].str.lower().str.contains(q,na=False)].head(50)
    st.caption(f"{len(v)} result(s)")
    cols = st.columns(3)
    for i,(_,row) in enumerate(v.iterrows()):
        with cols[i%3]:
            color = row["color"]
            st.markdown(f'<div class="med-card" style="border-top:3px solid {color};"><div class="med-emoji">{row["emoji"]}</div><div class="med-name">{row["name"][:36]}</div><div class="med-price" style="color:{color};">₹{row["price"]:,.2f}</div><div class="med-meta">{int(row["stock"]):,} units · {int(row["batches"])} batch(es)</div></div>', unsafe_allow_html=True)


def retailer_bills():
    st.markdown("## 🧾 My Bills")
    rid = st.session_state.retailer_id
    mine = [o for o in load_orders() if str(o.get("retailer_id","")).upper()==rid]
    if not mine: st.info("No orders yet."); return
    for o in mine[:20]:
        s = (o.get("status") or "pending").lower()
        st.markdown(f'<div class="bill-card {s}"><div class="row1"><div class="oid">🧾 {o.get("order_id","—")}</div><div class="badge {s}">{s.upper()}</div></div><div class="row2"><span>📅 {o.get("placed_at","—")}</span><span>📦 {len(o.get("items",[]))} item(s)</span></div><div class="row3"><span style="color:#8892b0;font-size:.75rem;">Total</span><span class="total">{money(o.get("total",0))}</span></div></div>', unsafe_allow_html=True)


def retailer_track():
    st.markdown("## 🚚 Track Your Orders")
    st.caption("From placement to handoff to the courier")

    rid = st.session_state.retailer_id
    mine = [o for o in load_orders() if str(o.get("retailer_id","")).upper()==rid][:20]
    if not mine:
        st.info("No orders yet."); return

    STATUS_MAP = {
        "pending":    {"stage":1, "label":"Awaiting Approval", "color":"#ffb547", "icon":"⏳"},
        "approved":   {"stage":2, "label":"Approved",          "color":"#00d4ff", "icon":"✅"},
        "packed":     {"stage":3, "label":"Packed",            "color":"#7b61ff", "icon":"📦"},
        "dispatched": {"stage":4, "label":"With Courier",      "color":"#00d47a", "icon":"🚚"},
        "delivered":  {"stage":5, "label":"Delivered",         "color":"#00d47a", "icon":"🎉"},
        "cancelled":  {"stage":0, "label":"Cancelled",         "color":"#ff4d6d", "icon":"❌"},
    }

    for o in mine:
        oid    = o.get("order_id","—")
        status = (o.get("status") or "pending").lower()
        total  = o.get("total", 0)
        info   = STATUS_MAP.get(status, STATUS_MAP["pending"])

        with st.expander(f"🧾 {oid} — {money(total)}  ·  {info['icon']} {info['label']}"):
            c1, c2 = st.columns([2, 1])
            with c1:
                st.markdown(f"**Order ID:** `{oid}`")
                st.markdown(f"**Placed:** {o.get('placed_at','—')}")
                st.markdown(f"**Total:** {money(total)}")
            with c2:
                st.markdown(
                    f'<div style="text-align:center;padding:.6rem;'
                    f'background:{info["color"]}22;border:1px solid {info["color"]}55;'
                    f'border-radius:10px;">'
                    f'<div style="font-size:1.6rem;">{info["icon"]}</div>'
                    f'<div style="color:{info["color"]};font-weight:700;'
                    f'font-size:.78rem;margin-top:.2rem;">{info["label"].upper()}</div></div>',
                    unsafe_allow_html=True)

            if status == "cancelled":
                st.error(f"❌ Cancelled — {o.get('cancel_reason','—')}")
                continue

            st.markdown("---")
            decision    = o.get("approval_decision") or ("manual" if status == "pending" else "approved")
            approver    = o.get("approved_by") or "—"
            reason      = o.get("approval_reason") or "—"
            approved_at = o.get("approved_at") or "—"

            if status == "pending":
                st.info(f"⏳ **Awaiting approval** — {reason if reason != '—' else 'Queued for owner review'}")
            else:
                st.success(f"✅ **{decision.title()} approval** · {approver} · {approved_at} — Reason: {reason}")

            st.markdown("##### 🏢 Company Side")
            stages = [("Placed","📥",1),("Approved","✅",2),("Packed","📦",3),("Dispatched","🚚",4)]
            html = '<div style="display:flex;justify-content:space-between;margin:.6rem 0;">'
            for lbl, ic, stg in stages:
                done = info["stage"] >= stg
                bg = "linear-gradient(135deg,#00d4ff,#7b61ff)" if done else "#1a1f2e"
                col = "#00d4ff" if done else "#8892b0"
                html += (f'<div style="text-align:center;flex:1;">'
                         f'<div style="width:40px;height:40px;border-radius:50%;background:{bg};'
                         f'display:flex;align-items:center;justify-content:center;'
                         f'margin:0 auto;font-size:1rem;">{ic}</div>'
                         f'<div style="font-size:.7rem;color:{col};margin-top:.35rem;'
                         f'font-weight:600;">{lbl}</div></div>')
            html += '</div>'
            st.markdown(html, unsafe_allow_html=True)

            if info["stage"] >= 4:
                awb = o.get("awb_number") or o.get("tracking_id") or "—"
                courier = o.get("courier") or "DHL"
                st.markdown("---")
                st.markdown(
                    f'<div style="background:linear-gradient(135deg,#ffb54722,#ffb54708);'
                    f'border-left:4px solid #ffb547;border-radius:10px;padding:.9rem 1.1rem;">'
                    f'<div style="font-weight:700;color:#ffb547;font-size:.95rem;">'
                    f'📮 Handed to {courier}</div>'
                    f'<div style="color:#c5cae9;font-size:.85rem;margin-top:.4rem;">'
                    f'<b>AWB:</b> <code style="color:#00d4ff;">{awb}</code></div></div>',
                    unsafe_allow_html=True)
                if awb != "—":
                    st.markdown(
                        f'<a href="https://www.dhl.com/in-en/home/tracking.html?tracking-id={awb}" '
                        f'target="_blank" style="display:inline-block;margin-top:.5rem;'
                        f'padding:.5rem 1.1rem;background:linear-gradient(90deg,#00d4ff,#7b61ff);'
                        f'color:#0a0e1a;font-weight:700;border-radius:10px;'
                        f'text-decoration:none;font-size:.85rem;">🚚 Track on {courier} →</a>',
                        unsafe_allow_html=True)
                st.caption("✅ Company responsibility ends at dispatch. Further tracking is by courier.")
            else:
                st.info("📮 Once dispatched, we'll share the courier AWB so you can track it directly.")




def retailer_ledger():
    st.markdown("## 💰 My Ledger")
    r = st.session_state.retailer
    lim = float(r.get("credit_limit") or 0)
    out = float(r.get("outstanding") or 0)
    av = lim - out
    m1,m2,m3 = st.columns(3)
    with m1:
        st.markdown(f'<div class="metric-tile"><div class="label">Credit Limit</div><div class="value">{money(lim)}</div></div>', unsafe_allow_html=True)
    with m2:
        st.markdown(f'<div class="metric-tile orange"><div class="label">Outstanding</div><div class="value">{money(out)}</div></div>', unsafe_allow_html=True)
    with m3:
        st.markdown(f'<div class="metric-tile green"><div class="label">Available</div><div class="value">{money(av)}</div></div>', unsafe_allow_html=True)
    st.markdown("### Statement")
    c1,c2 = st.columns(2)
    with c1: frm = st.date_input("From", datetime.now()-timedelta(days=30), key="l_f")
    with c2: to = st.date_input("To", datetime.now(), key="l_t")
    if st.button("📄 Download Statement"):
        st.success("Ready (demo).")


def retailer_placeholder(label, icon="⏳"):
    st.markdown(f"## {icon} {label}")
    st.info("Coming soon.")


# ═══════════════════════════════════════════════════════════
#  MENUS + SIDEBAR
# ═══════════════════════════════════════════════════════════
OWNER_MENU = [
    ("home","🏠","Dashboard"),
    ("map","💰","Collections"),("payments","💵","Payments"),          # NEW
    ("approvals","✅","Approvals"),("permissions","🔐","AI Permissions"),
    ("orders","📦","All Orders"),
    ("retailers","🏪","Retailers"),("salespeople","👥","Sales Reps"),
    ("inventory","📦","Inventory"),("expiry","⏰","Expiry"),
    ("ledger","💰","Ledger"),
    ("jarvis","🤖","JARVIS AI"),
    ("audit","🔍","Audit Log"),
    ("settings","⚙️","Settings"),("security","🛡️","Security"),("commandments","📜","Commandments"),("ai_analyzer","🧠","AI Analyzer"),
]
RETAILER_MENU = [
    ("home","🏠","Home"),("order","🛒","Place Order"),
    ("bills","🧾","My Bills"),("track","🚚","Track Deliveries"),
    ("stock","🔍","Stock Check"),("ledger","💰","My Ledger"),
    ("offers","🎁","Offers"),("profile","👤","Profile"),
]


def inject_security_headers():
    pass  # called from main()


def render_sidebar():
    role = st.session_state.role
    with st.sidebar:
        st.markdown(f'<div class="sidebar-brand"><div>{logo_html(52)}</div><div class="name">MEENA AGENCIES</div><div class="sub">{"OWNER · CONTROL" if role=="owner" else "RETAILER PORTAL"}</div></div>', unsafe_allow_html=True)
        badge_color = "#f59e0b" if role=="owner" else "#00d4ff"
        badge_label = "👑 OWNER" if role=="owner" else f"🏪 {st.session_state.retailer_id}"
        st.markdown(f'<div style="padding:.6rem .8rem;background:#1a1f2e;border:1px solid #2a3142;border-radius:10px;margin:.5rem 0 1rem;text-align:center;"><span style="color:{badge_color};font-weight:700;font-size:.78rem;">{badge_label}</span><div style="font-size:.68rem;color:#8892b0;margin-top:2px;">{st.session_state.get("user_name","")}</div></div>', unsafe_allow_html=True)

        st.markdown('<div style="font-size:.68rem;color:#8892b0;letter-spacing:1px;margin-bottom:.5rem;">MENU</div>', unsafe_allow_html=True)
        cur = st.session_state.get("page","home")
        menu = OWNER_MENU if role=="owner" else RETAILER_MENU
        for k,ic,lbl in menu:
            if st.button(f"{ic}  {lbl}", key=f"nav_{k}",
                         use_container_width=True,
                         type="primary" if k==cur else "secondary"):
                st.session_state.page = k
                if "cat_open" in st.session_state: st.session_state.cat_open=None
                st.rerun()
        st.markdown("---")
        if st.button("🚪  Sign Out", key="so", use_container_width=True):
            st.session_state.clear(); st.rerun()


# ═══════════════════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════════════════
def main():
    # role picker state
    if "role" not in st.session_state:
        if st.session_state.get("role_pick") == "owner": owner_login()
        elif st.session_state.get("role_pick") == "retailer": retailer_login()
        else: landing()
        return

    st.session_state.setdefault("page","home")
    inject_security_headers()
    render_sidebar()

    role = st.session_state.role
    p = st.session_state.page

    if role == "owner":
        if   p=="home":      owner_home()
        elif p=="map":       page_owner_map()
        elif p=="payments":  owner_payments()
        elif p=="approvals": owner_approvals()
        elif p=="permissions": owner_permissions()
        elif p=="orders":    owner_orders()
        elif p=="retailers": owner_retailers()
        elif p=="salespeople": owner_salespeople()
        elif p=="inventory": owner_inventory()
        elif p=="expiry":    owner_expiry()
        elif p=="ledger":    owner_ledger()
        elif p=="jarvis":    owner_jarvis()
        elif p=="settings":  owner_settings()
        elif p=="security":  owner_security()
        elif p=="commandments": owner_commandments()
        elif p=="ai_analyzer":  owner_ai_analyzer()
        else: owner_placeholder(next((m[2] for m in OWNER_MENU if m[0]==p), p.title()))
    else:
        if   p=="home":    retailer_home()
        elif p=="order":   retailer_order()
        elif p=="stock":   retailer_stock()
        elif p=="bills":   retailer_bills()
        elif p=="track":   retailer_track()
        elif p=="ledger":  retailer_ledger()
        else: retailer_placeholder(next((m[2] for m in RETAILER_MENU if m[0]==p), p.title()))


main()
